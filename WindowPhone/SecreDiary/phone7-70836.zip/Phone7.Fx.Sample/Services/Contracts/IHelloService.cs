﻿namespace Phone7.Fx.Sample.Services.Contracts
{
    public interface IHelloService
    {
        string SayHello();
    }
}