﻿using Phone7.Fx.Mvvm;

namespace Phone7.Fx.Sample.Views.Contracts
{
public interface IMainView:IView
{
         
}
}