﻿using Phone7.Fx.Sample.Views.Contracts;

namespace Phone7.Fx.Sample.Views
{
    public partial class MainView
    {
        // Constructor
        public MainView()
        {
            InitializeComponent();
        }
    }
}