namespace Phone7.Fx.Imaging
{
    internal struct BarcodeZone
    {
        public int Start { get; set; }
        public int End { get; set; }
    }
}