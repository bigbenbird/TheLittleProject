using System;

namespace Phone7.Fx.Tombstoning
{
    public class TemporaryStorage:Attribute
    {
        
    }
}