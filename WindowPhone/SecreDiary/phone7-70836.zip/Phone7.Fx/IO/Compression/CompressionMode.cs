namespace Phone7.Fx.IO.Compression
{
    public enum CompressionMode
    {
        Decompress,
        Compress,
    }
}