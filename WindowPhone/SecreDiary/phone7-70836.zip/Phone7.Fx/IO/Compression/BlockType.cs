namespace Phone7.Fx.IO.Compression
{
    internal enum BlockType
    {
        Uncompressed = 0,
        Static = 1,
        Dynamic = 2
    }
}