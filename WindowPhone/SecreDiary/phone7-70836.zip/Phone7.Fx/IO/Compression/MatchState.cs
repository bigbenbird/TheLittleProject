namespace Phone7.Fx.IO.Compression
{
    internal enum MatchState
    {
        HasSymbol = 1,
        HasMatch = 2,
        HasSymbolAndMatch = 3
    } 
}