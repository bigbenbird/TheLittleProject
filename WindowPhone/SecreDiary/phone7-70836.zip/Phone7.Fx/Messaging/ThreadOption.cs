namespace Phone7.Fx.Messaging
{
    public enum ThreadOption
    {
        PublisherThread,
        UIThread,
        BackgroundThread
    }
}