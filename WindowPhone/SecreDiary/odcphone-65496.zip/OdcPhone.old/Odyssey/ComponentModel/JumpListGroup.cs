﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace Odyssey.ComponentModel
{
    /// <summary>
    /// Contains groups of items for a JumpListCollectionView.
    /// </summary>
    public sealed class JumpListGroup
    {
        public ObservableCollection<object> Items { get; private set; }
        public int ItemCount { get { return Items.Count; } }
        public bool IsEmpty { get { return Items.Count == 0; } }

        public object Name { get; set; }
        public bool IsBottomLevel { get { return true; } }

        internal JumpListGroup()
            : base()
        {
            Items = new ObservableCollection<object>();
        }

    }
}
