﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Controls
{
    public enum FluidMode
    {
        /// <summary>
        /// Animates a page with a select ListBoxItem of a ListBox.
        /// </summary>
        List,

        /// <summary>
        /// Animates a page by giving the illusion that the page title would transition from a listbox item. 
        /// </summary>
        Detail
    }
}
