﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Controls
{
    /// <summary>
    /// PageAnimation with fade effect.
    /// </summary>
    public class FadeAnimation : PageAnimation
    {
        protected override bool ShowOverride(Page page)
        {
            Storyboard sb = GetClearStoryboard();

            DoubleAnimation opacity = new DoubleAnimation();
            sb.Children.Add(opacity);

            opacity.From = 0d;
            opacity.To = 1d;
            opacity.Duration = Duration;
            Storyboard.SetTarget(opacity, page);
            Storyboard.SetTargetProperty(opacity, new PropertyPath("Opacity"));
            sb.Begin();
            return true;
        }

        protected override bool HideOverride(Page page)
        {
            Storyboard sb = GetClearStoryboard();
            DoubleAnimation opacity = new DoubleAnimation();
            sb.Children.Add(opacity);

            opacity.To = 0d;
            opacity.Duration = Duration;
            Storyboard.SetTarget(opacity, page);
            Storyboard.SetTargetProperty(opacity, new PropertyPath("Opacity"));
            sb.Begin();
            return true;
        }
    }
}
