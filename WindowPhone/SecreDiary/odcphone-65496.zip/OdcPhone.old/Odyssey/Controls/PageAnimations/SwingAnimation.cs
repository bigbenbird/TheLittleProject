﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Controls
{
    public enum SwingMode
    {
        SwingIn,
        SwingOut
    }

    public class SwingAnimation : PageAnimation
    {

        public SwingMode SwingMode
        {
            get { return (SwingMode)GetValue(SwingModeProperty); }
            set { SetValue(SwingModeProperty, value); }
        }

        public static readonly DependencyProperty SwingModeProperty =
            DependencyProperty.Register("SwingMode", typeof(SwingMode), typeof(SwingAnimation), new PropertyMetadata(SwingMode.SwingIn));


        protected double Angle
        {
            get { return SwingMode == Controls.SwingMode.SwingIn ? -105d : 77d; }
        }

        protected override bool ShowOverride(Page page)
        {
            page.Loaded += OnPageLoaded;
            page.Projection = new PlaneProjection { CenterOfRotationX = 0d };
            Storyboard sb = GetClearStoryboard();
            InitializeShowStoryboard(page, sb, true);
            sb.Begin();
            sb.Pause();
            sb.SeekAlignedToLastTick(TimeSpan.FromMilliseconds(0));
            return true;
        }

        protected override bool HideOverride(Page page)
        {
            page.Projection = new PlaneProjection { CenterOfRotationX = 0d };
            Storyboard sb = GetClearStoryboard();
            InitializeHideStoryboard(page, sb);
            sb.Begin();
            return true;
        }


        void OnPageLoaded(object sender, RoutedEventArgs e)
        {
            Page page = sender as Page;
            page.Loaded -= OnPageLoaded;

            page.Projection = new PlaneProjection { CenterOfRotationX = 0d };
            Storyboard sb = InternalStoryboard;
            sb.Stop();
            InitializeShowStoryboard(page, sb, false);

            sb.Begin();
        }


        protected virtual void InitializeShowStoryboard(Page page, Storyboard sb, bool preload)
        {
            if (preload)
            {
                DoubleAnimation tileRotation = new DoubleAnimation();
                sb.Children.Add(tileRotation);
                tileRotation.To = 0d;
                tileRotation.From = Angle;
                tileRotation.Duration = Duration;
                tileRotation.EasingFunction = new CircleEase { EasingMode = EasingMode.EaseOut };
                Storyboard.SetTarget(tileRotation, page);
                Storyboard.SetTargetProperty(tileRotation, new PropertyPath("(UIElement.Projection).(PlaneProjection.RotationY)"));
            }
        }


        protected virtual void InitializeHideStoryboard(Page page, Storyboard sb)
        {
            DoubleAnimation tileRotation = new DoubleAnimation();
            sb.Children.Add(tileRotation);
            tileRotation.To = Angle;
            tileRotation.Duration = Duration;
            tileRotation.EasingFunction = new CircleEase { EasingMode = EasingMode.EaseIn };
            Storyboard.SetTarget(tileRotation, page);
            Storyboard.SetTargetProperty(tileRotation, new PropertyPath("(UIElement.Projection).(PlaneProjection.RotationY)"));
        }
    }
}
