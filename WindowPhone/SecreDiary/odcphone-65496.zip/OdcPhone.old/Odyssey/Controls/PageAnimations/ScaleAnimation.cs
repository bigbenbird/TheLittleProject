﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using System.Windows.Media.Imaging;
using System.Windows.Data;

namespace Odyssey.Controls
{
    /// <summary>
    /// Scales a page from a given factor to 1.0 in or out.
    /// </summary>
    public class ScaleAnimation : PageTransitionAnimation
    {  
        /// <summary>
        /// Gets or sets the scale factor from where to scale in or out.
        /// </summary>
        public double Scale
        {
            get { return (double)GetValue(ScaleProperty); }
            set { SetValue(ScaleProperty, value); }
        }

        public static readonly DependencyProperty ScaleProperty =
            DependencyProperty.Register("Scale", typeof(double), typeof(ScaleAnimation), new PropertyMetadata(0.3));


        protected override void PrepareShowAnimation(Panel parentPageImageContainer, Panel pageImageContainer, IEasingFunction ease)
        {
            Panel panel = pageImageContainer;
            panel.RenderTransformOrigin = new Point(0.5, 0.5);
            panel.RenderTransform = new CompositeTransform { ScaleX = this.Scale, ScaleY = this.Scale };

            DoubleAnimation opacityAnim = new DoubleAnimation
            {
                EasingFunction = ease,
                Duration = this.Duration,
                From = 0.0,
                To = 1.0
            };
            Storyboard.SetTarget(opacityAnim, panel);
            Storyboard.SetTargetProperty(opacityAnim, new PropertyPath("Opacity"));

            DoubleAnimation scaleX = new DoubleAnimation
            {
                Duration = Duration,
                EasingFunction = ease,
                To = 1.0
            };
            Storyboard.SetTargetProperty(scaleX, new PropertyPath("(UIElement.RenderTransform).(CompositeTransform.ScaleX)"));
            Storyboard.SetTarget(scaleX, panel);

            DoubleAnimation scaleY = new DoubleAnimation
            {
                Duration = Duration,
                EasingFunction = ease,
                To = 1.0
            };
            Storyboard.SetTargetProperty(scaleY, new PropertyPath("(UIElement.RenderTransform).(CompositeTransform.ScaleY)"));
            Storyboard.SetTarget(scaleY, panel);

            Storyboard sb = InternalStoryboard;
            sb.Children.Add(opacityAnim);
            sb.Children.Add(scaleX);
            sb.Children.Add(scaleY);
        }

        //protected override bool ShowOverride(Page page)
        //{
        //    page.Loaded += new RoutedEventHandler(OnPageLoaded);
        //    Brush background = page.Resources["PhoneBackgroundBrush"] as Brush;
        //    image = new Image { Stretch = System.Windows.Media.Stretch.None };
        //    Canvas cv = new Canvas();
        //    cv.SetBinding(WidthProperty, new Binding { Source = page, Path = new PropertyPath("ActualWidth") });
        //    cv.SetBinding(HeightProperty, new Binding { Source = page, Path = new PropertyPath("ActualHeight") });
        //    Storyboard sb = GetClearStoryboard();

        //    var ease = Ease?? new ExponentialEase { Exponent = 4.0, EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut };
        //    parentImage = PageTransitionService.PageImage;
        //    //PageTransitionService.PageImage = null;
        //    Grid g1 = new Grid { Background = background };
        //    if (parentImage != null)
        //    {
        //        g1.Children.Add(parentImage);
        //        cv.Children.Add(g1);
        //    }

        //    Grid g2 = new Grid { Background = background };
        //    g2.RenderTransformOrigin = new Point(0.5, 0.5);
        //    g2.RenderTransform = new CompositeTransform { ScaleX = this.Scale, ScaleY = this.Scale };

        //    g2.Children.Add(image);
        //    cv.Children.Add(g2);
        //    DoubleAnimation opacityAnim = new DoubleAnimation
        //    {
        //        EasingFunction = ease,
        //        Duration = this.Duration,
        //        From = 0.0,
        //        To = 1.0
        //    };
        //    Storyboard.SetTarget(opacityAnim, g2);
        //    Storyboard.SetTargetProperty(opacityAnim, new PropertyPath("Opacity"));

        //    DoubleAnimation scaleX = new DoubleAnimation
        //    {
        //        Duration = Duration,
        //        EasingFunction = ease,
        //        To = 1.0
        //    };
        //    Storyboard.SetTargetProperty(scaleX, new PropertyPath("(UIElement.RenderTransform).(CompositeTransform.ScaleX)"));
        //    Storyboard.SetTarget(scaleX, g2);

        //    DoubleAnimation scaleY = new DoubleAnimation
        //    {
        //        Duration = Duration,
        //        EasingFunction = ease,
        //        To = 1.0
        //    };
        //    Storyboard.SetTargetProperty(scaleY, new PropertyPath("(UIElement.RenderTransform).(CompositeTransform.ScaleY)"));
        //    Storyboard.SetTarget(scaleY, g2);


        //    sb.Children.Add(opacityAnim);
        //    sb.Children.Add(scaleX);
        //    sb.Children.Add(scaleY);

        //    Popup popup = new Popup { Child = cv };
        //    popup.IsOpen = true;
        //    sb.Completed += (ss, ee) =>
        //        {
        //            popup.IsOpen = false;
        //            g1.Children.Clear();
        //            cv.Children.Clear();
        //            image = null;
        //        };
        //    sb.Begin();
        //    sb.Pause();
        //    return true;
        //}

        //void OnPageLoaded(object sender, RoutedEventArgs e)
        //{
        //    Page page = sender as Page;
        //    page.Loaded -= OnPageLoaded;
        //    WriteableBitmap bm = new WriteableBitmap(page, null);
        //    image.Source = bm;

        //    //note: beginning the storyboard when the page is loaded minimizes the delay that occurs while the page is prepared:
        //    InternalStoryboard.Begin();
        //}

        protected override void PrepareHideAnimation(Panel parentImageContainer, Panel pageImageContainer, IEasingFunction ease)
        {
            Panel panel = pageImageContainer;
            Storyboard sb = InternalStoryboard;

            panel.RenderTransformOrigin = new Point(0.5, 0.5);
            panel.RenderTransform = new CompositeTransform();

            DoubleAnimation opacityAnim = new DoubleAnimation
            {
                EasingFunction = ease,
                Duration = this.Duration,
                To = 0.0
            };
            Storyboard.SetTarget(opacityAnim, panel);
            Storyboard.SetTargetProperty(opacityAnim, new PropertyPath("Opacity"));

            DoubleAnimation scaleX = new DoubleAnimation
            {
                Duration = Duration,
                EasingFunction = ease,
                To = this.Scale
            };
            Storyboard.SetTargetProperty(scaleX, new PropertyPath("(UIElement.RenderTransform).(CompositeTransform.ScaleX)"));
            Storyboard.SetTarget(scaleX, panel);

            DoubleAnimation scaleY = new DoubleAnimation
            {
                Duration = Duration,
                EasingFunction = ease,
                To = this.Scale
            };
            Storyboard.SetTargetProperty(scaleY, new PropertyPath("(UIElement.RenderTransform).(CompositeTransform.ScaleY)"));
            Storyboard.SetTarget(scaleY, panel);
            sb.Children.Add(scaleX);
            sb.Children.Add(scaleY);


            sb.Children.Add(opacityAnim);
        }

        //protected override bool HideOverride(Page page)
        //{
        //    WriteableBitmap bm = new WriteableBitmap(page, null);

        //    Brush background = page.Resources["PhoneBackgroundBrush"] as Brush;
        //    image = new Image { Source = bm, Stretch = System.Windows.Media.Stretch.None };
        //    Canvas cv = new Canvas();
        //    cv.SetBinding(WidthProperty, new Binding { Source = page, Path = new PropertyPath("ActualWidth") });
        //    cv.SetBinding(HeightProperty, new Binding { Source = page, Path = new PropertyPath("ActualHeight") });
        //    Storyboard sb = GetClearStoryboard();

        //    var ease = Ease?? new ExponentialEase { Exponent = 4.0, EasingMode = System.Windows.Media.Animation.EasingMode.EaseIn };
        //    Grid g1 = new Grid { Background = background };
        //    if (parentImage == null) parentImage = PageTransitionService.PageImage;
        //    if (parentImage != null)
        //    {
        //        g1.Children.Add(parentImage);
        //        cv.Children.Add(g1);
        //    }

        //    Grid g2 = new Grid { Background = background };
        //    g2.RenderTransformOrigin = new Point(0.5, 0.5);
        //    g2.RenderTransform = new CompositeTransform();

        //    g2.Children.Add(image);
        //    cv.Children.Add(g2);
        //    DoubleAnimation opacityAnim = new DoubleAnimation
        //    {
        //        EasingFunction = ease,
        //        Duration = this.Duration,
        //        To = 0.0
        //    };
        //    Storyboard.SetTarget(opacityAnim, g2);
        //    Storyboard.SetTargetProperty(opacityAnim, new PropertyPath("Opacity"));

        //    DoubleAnimation scaleX = new DoubleAnimation
        //    {
        //        Duration = Duration,
        //        EasingFunction = ease,
        //        To = this.Scale
        //    };
        //    Storyboard.SetTargetProperty(scaleX, new PropertyPath("(UIElement.RenderTransform).(CompositeTransform.ScaleX)"));
        //    Storyboard.SetTarget(scaleX, g2);

        //    DoubleAnimation scaleY = new DoubleAnimation
        //    {
        //        Duration = Duration,
        //        EasingFunction = ease,
        //        To = this.Scale
        //    };
        //    Storyboard.SetTargetProperty(scaleY, new PropertyPath("(UIElement.RenderTransform).(CompositeTransform.ScaleY)"));
        //    Storyboard.SetTarget(scaleY, g2);
        //    sb.Children.Add(scaleX);
        //    sb.Children.Add(scaleY);


        //    sb.Children.Add(opacityAnim);

        //    Popup popup = new Popup { Child = cv };
        //    popup.IsOpen = true;
        //    this.popup = popup;
        //    sb.Begin();
        //    return true;
        //}

        //public override void OnNavigated(Page page)
        //{
        //    if (popup != null)
        //    {
        //        popup.IsOpen = false;
        //        popup = null;
        //    }
        //    base.OnNavigated(page);
        //}
    }
}
