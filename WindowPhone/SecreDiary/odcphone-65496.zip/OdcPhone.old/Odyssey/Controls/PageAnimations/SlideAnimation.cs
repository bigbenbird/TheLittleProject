﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using System.Windows.Media.Imaging;
using System.Windows.Data;

namespace Odyssey.Controls
{
    /// <summary>
    /// Animates from/to this page with a slide effect from the bottom or top (depending on the values of FromOffset and ToOffset).
    /// SlideAnimation expects to be navigated from a page which has <see cref=" SnaphsotAnimation"/> applied.
    /// </summary>
    public class SlideAnimation : PageTransitionAnimation
    {
        /// <summary>
        /// Gets or sets the offset where to slide to when the page becomes visible. The default value is 200.0
        /// This is a dependency property.
        /// </summary>
        public double ToOffset
        {
            get { return (double)GetValue(ToOffsetProperty); }
            set { SetValue(ToOffsetProperty, value); }
        }

        // Using a DependencyProperty as the backing store for EndOffset.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ToOffsetProperty =
            DependencyProperty.Register("ToOffset", typeof(double), typeof(SlideAnimation), new PropertyMetadata(200d));



        /// <summary>
        /// Gets or sets the offset from where to slide from when the page becomes visible. The default value is 400.0
        /// This is a dependency property.
        /// </summary>
        public double FromOffset
        {
            get { return (double)GetValue(FromOffsetProperty); }
            set { SetValue(FromOffsetProperty, value); }
        }

        /// <summary>
        /// Gets or sets the offset from where to slide to. The default value is 400.0
        /// </summary>
        public static readonly DependencyProperty FromOffsetProperty =
            DependencyProperty.Register("FromOffset", typeof(double), typeof(SlideAnimation), new PropertyMetadata(400.0));


        //protected override bool HideOverride(Page page)
        //{
        //    WriteableBitmap bm = new WriteableBitmap(page, null);

        //    Brush background = page.Resources["PhoneBackgroundBrush"] as Brush;
        //    image = new Image { Source = bm, Stretch = System.Windows.Media.Stretch.None };
        //    Canvas cv = new Canvas();
        //    cv.SetBinding(WidthProperty, new Binding { Source = page, Path = new PropertyPath("ActualWidth") });
        //    cv.SetBinding(HeightProperty, new Binding { Source = page, Path = new PropertyPath("ActualHeight") });
        //    Storyboard sb = GetClearStoryboard();

        //    var ease = new ExponentialEase
        //    {
        //        Exponent = 4.0,
        //        EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut
        //    };
        //    Grid g1 = new Grid { Background = background };
        //    if (parentImage != null)
        //    {
        //        g1.Children.Add(parentImage);
        //        cv.Children.Add(g1);
        //    }

        //    Grid g2 = new Grid { Background = background };
        //    g2.RenderTransform = new TranslateTransform { Y = 0.0 };

        //    g2.Children.Add(image);
        //    cv.Children.Add(g2);
        //    DoubleAnimation opacityAnim = new DoubleAnimation
        //    {
        //        EasingFunction = ease,
        //        Duration = this.Duration,
        //        To = 0.0
        //    };
        //    Storyboard.SetTarget(opacityAnim, g2);
        //    Storyboard.SetTargetProperty(opacityAnim, new PropertyPath("Opacity"));

        //    DoubleAnimation translateAnim = new DoubleAnimation
        //    {
        //        Duration = Duration,
        //        EasingFunction = ease,
        //        To = ToOffset
        //    };
        //    Storyboard.SetTargetProperty(translateAnim, new PropertyPath("(UIElement.RenderTransform).(TranslateTransform.Y)"));
        //    Storyboard.SetTarget(translateAnim, g2);

        //    sb.Children.Add(opacityAnim);
        //    sb.Children.Add(translateAnim);

        //    Popup popup = new Popup { Child = cv };
        //    popup.IsOpen = true;
        //    this.popup = popup;
        //    sb.Begin();
        //    return true;
        //}

        protected override void PrepareShowAnimation(Panel parentImageContainer, Panel pageImageContainer, IEasingFunction ease)
        {
            Panel container = pageImageContainer;
            container.RenderTransform = new TranslateTransform { Y = FromOffset };
            DoubleAnimation opacityAnim = new DoubleAnimation
            {
                EasingFunction = ease,
                Duration = this.Duration,
                From = 0.0,
                To = 1.0
            };
            Storyboard.SetTarget(opacityAnim, container);
            Storyboard.SetTargetProperty(opacityAnim, new PropertyPath("Opacity"));

            DoubleAnimation translateAnim = new DoubleAnimation
            {
                Duration = Duration,
                EasingFunction = ease,
                To = 0.0
            };
            Storyboard.SetTargetProperty(translateAnim, new PropertyPath("(UIElement.RenderTransform).(TranslateTransform.Y)"));
            Storyboard.SetTarget(translateAnim, container);

            this.InternalStoryboard.Children.Add(opacityAnim);
            this.InternalStoryboard.Children.Add(translateAnim);
        }

        protected override void PrepareHideAnimation(Panel parentPageImageContainer, Panel pageImageContainer, IEasingFunction ease)
        {
            DoubleAnimation opacityAnim = new DoubleAnimation
            {
                EasingFunction = ease,
                Duration = this.Duration,
                To = 0.0
            };
            Storyboard.SetTarget(opacityAnim, pageImageContainer);
            Storyboard.SetTargetProperty(opacityAnim, new PropertyPath("Opacity"));

            DoubleAnimation translateAnim = new DoubleAnimation
            {
                Duration = Duration,
                EasingFunction = ease,
                To = ToOffset
            };
            Storyboard.SetTargetProperty(translateAnim, new PropertyPath("(UIElement.RenderTransform).(TranslateTransform.Y)"));
            Storyboard.SetTarget(translateAnim, pageImageContainer);

            InternalStoryboard.Children.Add(opacityAnim);
            InternalStoryboard.Children.Add(translateAnim);
        }


    }
}
