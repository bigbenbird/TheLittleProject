﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;

namespace Odyssey.Controls
{
    /// <summary>
    /// PageAnimation which creates a snapshot of the current page when hiding. SnapshotAnimation is used when navigating to a page with <see cref="SlideAnimation"/>.
    /// </summary>
    public class SnapshotAnimation : PageAnimation
    {

        protected override bool ShowOverride(Page page)
        {
            return false;
        }

        protected override bool HideOverride(Page page)
        {
            WriteableBitmap bm = new WriteableBitmap(page, null);
            Image image = new Image { Source = bm, Stretch = System.Windows.Media.Stretch.None };
            PageTransitionService.PageImage = image;
            return false;
        }
    }
}
