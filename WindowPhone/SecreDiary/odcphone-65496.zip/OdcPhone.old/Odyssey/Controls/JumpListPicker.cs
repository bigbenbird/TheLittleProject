﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;

namespace Odyssey.Controls
{
    internal class JumpListPicker : ListBox
    {
        const double animDuration = 350d;

        public JumpListPicker()
            : base()
        {
            TileProjection = new PlaneProjection();
        }



        public PlaneProjection TileProjection
        {
            get { return (PlaneProjection)GetValue(TileProjectionProperty); }
            set { SetValue(TileProjectionProperty, value); }
        }

        public static readonly DependencyProperty TileProjectionProperty =
            DependencyProperty.Register("TileProjection", typeof(PlaneProjection), typeof(JumpListPicker), new PropertyMetadata(null));


        public double TileRotation
        {
            get { return (double)GetValue(TileRotationProperty); }
            set { SetValue(TileRotationProperty, value); }
        }

        public static readonly DependencyProperty TileRotationProperty =
            DependencyProperty.Register("TileRotation", typeof(double), typeof(JumpListPicker), new PropertyMetadata(0d));


        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            base.PrepareContainerForItemOverride(element, item);
            ListBoxItem listBoxItem = element as ListBoxItem;

            Binding b = new Binding();
            b.Source = TileProjection;
            listBoxItem.SetBinding(ProjectionProperty, b);

        }

        public void Show()
        {
            Storyboard sb = new Storyboard();
            DoubleAnimation opacity = new DoubleAnimation();
            sb.Children.Add(opacity);

            IEasingFunction ease = new CircleEase {EasingMode = System.Windows.Media.Animation.EasingMode.EaseIn };
            opacity.From = 0d;
            opacity.To = 1f;
            opacity.EasingFunction = ease;
            opacity.Duration = TimeSpan.FromMilliseconds(animDuration);
            Storyboard.SetTarget(opacity, this);
            Storyboard.SetTargetProperty(opacity, new PropertyPath("Opacity"));

            DoubleAnimation tileRotation = new DoubleAnimation();
            sb.Children.Add(tileRotation);
            tileRotation.To = 0d;
            tileRotation.From = 90d;
            tileRotation.EasingFunction = ease;
            tileRotation.Duration = TimeSpan.FromMilliseconds(animDuration);
            Storyboard.SetTarget(tileRotation, TileProjection);
            Storyboard.SetTargetProperty(tileRotation, new PropertyPath("RotationX"));
            sb.Begin();
        }

        public void Close()
        {
           Storyboard sb = new Storyboard();
            DoubleAnimation opacity = new DoubleAnimation();
            sb.Children.Add(opacity);
            IEasingFunction ease = new CircleEase {EasingMode = System.Windows.Media.Animation.EasingMode.EaseIn };

            opacity.EasingFunction = ease;
            opacity.To = 0d;
            opacity.Duration = TimeSpan.FromMilliseconds(animDuration);
            Storyboard.SetTarget(opacity, this);
            Storyboard.SetTargetProperty(opacity, new PropertyPath("Opacity"));

            DoubleAnimation tileRotation = new DoubleAnimation();
            sb.Children.Add(tileRotation);
            tileRotation.To = 90d;
            tileRotation.EasingFunction = ease;
            tileRotation.Duration = TimeSpan.FromMilliseconds(animDuration);
            //tileRotation.EasingFunction = new ExponentialEase { EasingMode = EasingMode.EaseOut, Exponent = 6d };
            //tileRotation.EasingFunction = new CircleEase { EasingMode = EasingMode.EaseOut };
            Storyboard.SetTarget(tileRotation, TileProjection);
            Storyboard.SetTargetProperty(tileRotation, new PropertyPath("RotationX"));
            sb.Completed += new EventHandler(sb_Completed);
            sb.Begin();
        }

        void sb_Completed(object sender, EventArgs e)
        {
            if (Closed != null) Closed(this, e);
        }

        public event EventHandler Closed;
    }
}
