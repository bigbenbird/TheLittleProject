﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace Odyssey.Controls
{
    /// <summary>
    /// Extended PhoneApplicationPage that supports safe animation.
    /// Due to a bug in the current NavigationService, NavigationService.Navigating does not support canceling for NavigationMode.Back. there fore
    /// the PhoneApplicationPage.BackKeyPress event is used by PageTransitionService. However, if this event is hooked and canceld by another code,
    /// the PageTransitionService would not recognize a later canceling, which this control fixes.
    /// </summary>
    public class AnimationPhoneApplicationPage : PhoneApplicationPage
    {
        protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
        {
            base.OnBackKeyPress(e);
            PageTransitionService.OnBackKeyPress(this, e);
        }
    }
}
