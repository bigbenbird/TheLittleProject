﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Markup;
using System.Diagnostics;
using Odyssey.Classes;
using System.Linq;

namespace Odyssey.Controls
{
    [ContentProperty("Children")]
    public class ExpansionPanel : Panel
    {
        private double itemHeight;
        
        public ExpansionPanel()
            : base()
        {
//            this.Loaded += new RoutedEventHandler(ExpansionPanel_Loaded);
        }

        //void ExpansionPanel_Loaded(object sender, RoutedEventArgs e)
        //{
        //    DropDown dd = Parent.GetVisualAncestors().OfType<DropDown>().FirstOrDefault() as DropDown;         
        //    Debug.WriteLine(dd);
        //}


        public int SelectedIndex
        {
            get { return (int)GetValue(SelectedIndexProperty); }
            set { SetValue(SelectedIndexProperty, value); }
        }

        public static readonly DependencyProperty SelectedIndexProperty =
            DependencyProperty.Register("SelectedIndex", typeof(int), typeof(ExpansionPanel), new PropertyMetadata(0, OnSelectedIndexPropertyChanged));

        private static void OnSelectedIndexPropertyChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
        {

            ExpansionPanel p = o as ExpansionPanel;
            p.InvalidateArrange();
        }

        public double ExpansionFactor
        {
            get { return (double)GetValue(ExpansionFactorProperty); }
            set { SetValue(ExpansionFactorProperty, value); }
        }

        public static readonly DependencyProperty ExpansionFactorProperty =
            DependencyProperty.Register("ExpansionFactor", typeof(double), typeof(ExpansionPanel), new PropertyMetadata(0.0, OnExpansionFactorPropertyChanged));

        private static void OnExpansionFactorPropertyChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
        {
            ExpansionPanel p = o as ExpansionPanel;
            if (p != null)
            {
                p.InvalidateArrange();
                p.InvalidateMeasure();
            }
        }



        protected override Size MeasureOverride(Size availableSize)
        {
            double h = 0;
            double w = 0.0;
            foreach (UIElement child in Children)
            {
                child.Measure(availableSize);
                h = Math.Max(h, child.DesiredSize.Height);
                w = Math.Max(w, child.DesiredSize.Width);
            }
            int n = GetNumberOfItems();
            itemHeight = h;
            h = n * h;
            if (!double.IsNaN(MaxHeight)) h = Math.Min(MaxHeight, h);
            if (!double.IsNaN(MinHeight)) h = Math.Max(MinHeight, h);

            double eFactor = ExpansionFactor;
            h = MathUtil.Interpolate(itemHeight, h, eFactor);
            return new Size(w, h);
        }

        private int GetNumberOfItems()
        {
            return Math.Max(1, Children.Count);
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            double top = GetStartOffset();
            double w = finalSize.Width;
            foreach (UIElement child in Children)
            {
                double h = Math.Max(itemHeight, child.DesiredSize.Height);
                child.Arrange(new Rect(0.0, top, w, h));
                top += itemHeight;
            }

            double h0 = Math.Min(finalSize.Height, this.DesiredSize.Height);
            Clip = new RectangleGeometry()
            {
                Rect = new Rect(0, 0, w, h0)
            };
            return new Size(w, h0);
        }

        private double GetStartOffset()
        {
            double offset = itemHeight * Math.Max(0, SelectedIndex) * (1.0 - ExpansionFactor);
            return -offset;
        }

    }

}
