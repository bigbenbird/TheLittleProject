﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Windows.Data;

namespace Odyssey.Controls
{
    /// <summary>
    /// Specialized ListBoxItem to be used with OdcListBox.
    /// </summary>
    public class OdcListBoxItem : ListBoxItem
    {

        /// <summary>
        /// Gets whether the item contains a group header.
        /// </summary>
        public bool IsHeader { get; internal set; }

        public OdcListBoxItem()
            : base()
        {
                        Loaded += new RoutedEventHandler(OnLoaded);
            Unloaded += new RoutedEventHandler(OnUnloaded);
        }

        void OnUnloaded(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("Unloaded");
        }

        void OnLoaded(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("Loaded");
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            if (IsHeader) e.Handled = true;
            base.OnMouseLeftButtonDown(e);
        }

        /// <summary>
        /// ...wondering how you could distinguish bitween left and right finger?
        /// </summary>
        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
        {
            if (IsHeader)
            {
                OdcListBox box = GetParentOdcListBox();
                if (box != null && box.IsEnabled)
                {
                    e.Handled = true;
                    box.OnHeaderItemTap(this);
                }
            }
            base.OnMouseLeftButtonUp(e);
        }

        private OdcListBox GetParentOdcListBox()
        {
            var parent = VisualTreeHelper.GetParent(this);
            while (parent != null && !(parent is OdcListBox)) parent = VisualTreeHelper.GetParent(parent);
            OdcListBox box = parent as OdcListBox;
            return box;
        }

    }
}
