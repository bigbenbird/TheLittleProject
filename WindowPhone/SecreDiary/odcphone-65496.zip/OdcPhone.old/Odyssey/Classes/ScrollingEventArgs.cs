﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Classes
{
    public class ScrollingEventArgs:EventArgs
    {
        public bool IsScrolling { get; private set; }

        public ScrollingEventArgs(bool isScrolling)
            : base()
        {
            this.IsScrolling = isScrolling;
        }
    }
}
