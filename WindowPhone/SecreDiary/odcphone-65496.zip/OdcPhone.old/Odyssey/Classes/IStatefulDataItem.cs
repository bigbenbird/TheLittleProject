﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Odyssey.Classes
{
    /// <summary>
    /// Adds state information to a data item, which can be bound to a StatfulControl in an ItemTemplate.
    /// </summary>
    public interface IStatefulDataItem : INotifyPropertyChanged
    {
        /// <summary>
        /// Gets the current state of the data item.
        /// </summary>
        string State { get; }
    }
}
