﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Classes
{
    /// <summary>
    /// Secifies the requirements for a data item to allow lazy loading in a <see cref="OdcListBox"/>.
    /// </summary>
    public interface ILazyDataItem
    {
        /// <summary>
        /// Occurs when the item is in the visible area and the OdcListBox changes it's IsScrolling value to true.
        /// </summary>
        void Scroll();

        /// <summary>
        /// Occurs when the item becomes visible in an OdcListBox and OdcListBox.IsScrolling is set to false
        /// </summary>
        void Load();

        /// <summary>
        /// Occurs when the item get outside the visible area in an OdcListBox, or when the data item is no longer bound with the UI.
        /// If necassary, the item can now unload data which consumes a lot of memory.
        /// </summary>
        void Unload();
    }
}
