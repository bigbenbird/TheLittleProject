﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Classes
{
    /// <summary>
    /// Class to refer to a DataTemplate in a ResourceDictionary.
    /// </summary>
    public class DataTemplateRef : DependencyObject
    {
        /// <summary>
        /// Gets or sets the key to identify this class in a ResourceDictionary.
        /// </summary>
        public object Key
        {
            get { return (object)GetValue(KeyProperty); }
            set { SetValue(KeyProperty, value); }
        }

        /// <summary>
        /// Gets or sets the key to identify this class in a ResourceDictionary.
        /// </summary>
        public static readonly DependencyProperty KeyProperty =
            DependencyProperty.Register("Key", typeof(object), typeof(DataTemplateRef), new PropertyMetadata(null));


        /// <summary>
        /// Gets or sets the DataTemplate to which this class refers to.
        /// </summary>
        public DataTemplate DataTemplate
        {
            get { return (DataTemplate)GetValue(DataTemplateProperty); }
            set { SetValue(DataTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the DataTemplate to which this class refers to.
        /// </summary>
        public static readonly DependencyProperty DataTemplateProperty =
            DependencyProperty.Register("DataTemplate", typeof(DataTemplate), typeof(DataTemplateRef), new PropertyMetadata(null));

        
    }
}
