﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;

namespace OdcDemo.ViewModels
{
    public class AnimationViewModel
    {
        public ObservableCollection<AnimationPageItem> Items { get; private set; }       

        public AnimationViewModel()
            : base()
        {
            Items = new ObservableCollection<AnimationPageItem>();
            foreach (var item in GetItems())
            {
                Items.Add(item);
            }
        }

        public IEnumerable<AnimationPageItem> GetItems()
        {
            yield return new AnimationPageItem("fade", "/Pages/FadePage.xaml", "Fades between pages.");
            yield return new AnimationPageItem("swing", "/Pages/SwingPage.xaml", "Swings the current page out and the next page in.");
            yield return new AnimationPageItem("turnstile", "/Pages/JumpListPage.xaml", "swings each item of a listbox delayed into a OdcListBox demo page.");
            yield return new AnimationPageItem("fluid", "/Pages/FluidPage.xaml", "Animates the selected Item into the details page as title.");
            yield return new AnimationPageItem("slide", "/Pages/SlidePage.xaml", "Slides the new page from the bottom up.");
            yield return new AnimationPageItem("zoom", "/Pages/ZoomPage.xaml", "ScaleAnimation with ScaleFactor=0.5.");
            yield return new AnimationPageItem("explode", "/Pages/ExplodePage.xaml", "ScaleAnimation with ScaleFactor=3.0 and custom EasingFunction.");
        }
    }
}
