﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using Microsoft.Expression.Interactivity.Core;

namespace OdcDemo
{
    /// <summary>
    /// Group description for ItemViewModel items.
    /// </summary>
    public class ItemGroupDescripton : GroupDescription
    {
        /// <summary>
        /// Determines the group for a specific item.
        /// </summary>
        /// <param name="item">Data item for which to determine the group. In this case this class is of type ItemViewModel.</param>
        /// <param name="level">Currently, only 0 level is supported.</param>
        /// <param name="culture">Culture for culture specific determination (ignored here).</param>
        /// <returns>Gets the group key for the given item.</returns>
        public override object GroupNameFromItem(object item, int level, System.Globalization.CultureInfo culture)
        {
            ItemViewModel m = item as ItemViewModel;
            string s = m.LineOne;
            if (string.IsNullOrEmpty(s)) return "#";
            char c = char.ToLower(s[0]);
            return c.ToString();
        }

        /// <summary>
        /// Since the jump list is supposed to show all letters from # to z and not only those who are indeed available,
        /// all possible groups from # to z are added at this place.
        /// </summary>
        public ItemGroupDescripton()
            : base()
        {
            foreach(char c in "#abcdefghijklmnopqrstuvwxyz")
            {
                this.GroupNames.Add(c.ToString());
            }
        }
    }
}
