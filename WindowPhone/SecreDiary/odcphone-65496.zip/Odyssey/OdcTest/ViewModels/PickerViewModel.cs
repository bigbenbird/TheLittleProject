﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.ViewModels;
using System.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace OdcTest.ViewModels
{
    public class PickerViewModel : ViewModelBase
    {
        public PickerViewModel()
            : base()
        {
            Days = new ObservableCollection<string>();

            foreach (var item in Enumerable.Range(1, 31).Select(x => x.ToString("D2"))) Days.Add(item);
            Months = Enumerable.Range(1, 12).Select(x => x.ToString("D2")).ToArray();
            Years = Enumerable.Range(1980, 60).Select(x => x.ToString("D4")).ToArray();

            selectedDay = Days[6];
            selectedMonth = Months[3];
            selectedYear = Years[2011 - 1980];
        }

        private string selectedDay;
        private string selectedMonth;
        private string selectedYear;

        public string SelectedYear
        {
            get { return selectedYear; }
            set
            {
                if (selectedYear != value)
                {
                    selectedYear = value;
                    OnPropertyChanged("SelectedYear");
                }
            }
        }


        public string SelectedMonth
        {
            get { return selectedMonth; }
            set
            {
                if (selectedMonth != value)
                {
                    selectedMonth = value;
                    OnPropertyChanged("SelectedMonth");
                    OnMonthChanged();
                }
            }
        }



        public string SelectedDay
        {
            get { return selectedDay; }
            set
            {
                if (selectedDay != value)
                {
                    selectedDay = value;
                    OnPropertyChanged("SelectedDay");
                }
            }
        }


        public ObservableCollection<string> Days { get; private set; }
        public string[] Months { get; private set; }
        public string[] Years { get; private set; }

        private readonly int[] daysPerMonth = new[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

        private void OnMonthChanged()
        {
            if (selectedMonth != null)
            {
                int selectedMonthIndex = Array.IndexOf<string>(Months, selectedMonth);
                int days = daysPerMonth[selectedMonthIndex] - 1;
                while (Days.Count > days) Days.RemoveAt(Days.Count - 1);
                for (int i = Days.Count; i <= days; i++)
                {
                    Days.Add((i + 1).ToString("D2"));
                }
                if (!Days.Contains(selectedDay))
                {
                    SelectedDay = Days[Days.Count - 1];
                }
            }
        }


    }
}
