﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.ViewModels;
using System.Collections.Generic;
using OdcTest.Models;
using System.Threading;

namespace OdcTest.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        public MainViewModel()
            : base()
        {
            Items = new List<MainItem>();

            Items.Add(new MainItem("Pickers", "/Views/PickersPage.xaml", null, true));
            Items.Add(new MainItem("OdcListBox", "/Views/OdcListBoxPage.xaml", "+ continuum effect"));
            Items.Add(new MainItem("Original ListBox", "/Views/ListBoxPage.xaml", "+ continuum effect"));
            Items.Add(new MainItem("Feather Effect", "/Views/FeatherFxDemo.xaml"));
            Items.Add(new MainItem("Alphabetic JumpList", "/Views/JumpListPage.xaml", "show a quick jump list"));
            Items.Add(new MainItem("Long JumpList", "/Views/LongJumpListPage.xaml", "show a quick jump list"));
            Items.Add(new MainItem("Panorama", "/Views/PanoramaPage.xaml", ""));
        }

        public List<MainItem> Items { get; private set; }

        private MainItem selectedItem;

        public MainItem SelectedItem
        {
            get { return selectedItem; }
            set
            {
                if (selectedItem != value)
                {
                    selectedItem = value;
                    OnPropertyChanged("SelectedItem");
                    if (value != null) NavigateTo(value);
                }
            }
        }

        private void NavigateTo(MainItem item)
        {
            Uri uri = new Uri(item.Url, UriKind.Relative);
            Dispatcher.BeginInvoke(() =>
                {
                    if (item.Wait)
                    {
                        Thread.Sleep(250);
                    }
                    NavigationService.Navigate(uri);
                });
        }

    }
}
