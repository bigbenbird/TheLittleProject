﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.ViewModels;
using OdcTest.Models;
using System.Collections.Generic;
using System.Linq;

namespace OdcTest.ViewModels
{
    public class PickersViewModel : ViewModelBase
    {
        private List<DataItem> items;

        public PickersViewModel()
            : base()
        {
            items = Enumerable.Range(1, 20).Select(i => new DataItem(null,i, "Item " + i.ToString())).ToList();
        }

        private DateTime? date;
        private DateTime? time = DateTime.Now;
        private DataItem selectedItem;

        public DataItem SelectedItem
        {
            get { return selectedItem; }
            set
            {
                if (selectedItem != value)
                {
                    selectedItem = value;
                    OnPropertyChanged("SelectedItem");
                }
            }
        }


        public List<DataItem> Items { get { return items; } }

        public DateTime? Time
        {
            get { return time; }
            set
            {
                if (time != value)
                {
                    time = value;
                    OnPropertyChanged("Time");
                }
            }
        }

        public DateTime? Date
        {
            get { return date; }
            set
            {
                if (date != value)
                {
                    date = value;
                    OnPropertyChanged("Date");
                }
            }
        }


    }
}
