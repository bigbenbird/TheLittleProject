﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.ViewModels;
using OdcTest.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace OdcTest.ViewModels
{
    public class JumpListViewModel : ViewModelBase
    {
        private static bool swap;
        public JumpListViewModel()
            : base()
        {
            Items = new List<JumpListItem>();
            InitItems();
        }

        private JumpListItem selectedItem;

        public JumpListItem SelectedItem
        {
            get { return selectedItem; }
            set
            {
                if (selectedItem != value)
                {
                    selectedItem = value;
                    OnPropertyChanged("SelectedItem");
                    OnSelectedItemChanged(value);
                }
            }
        }

        

        public List<JumpListItem> Items { get; private set; }


        protected virtual void InitItems()
        {
            AddItems("a", 5);
            string s = swap ? "b" : "c";
            swap ^= true;
            AddItems(s, 35);

            AddItems("e", 3);
            AddItems("f", 13);
            AddItems("m", 20);
            AddItems("x", 5);
        }

        protected void AddItems(string title, int count)
        {
            Items.Add(new JumpListItem(1, title) { IsEnabled = true, IsHeader = true });
            foreach (var item in Enumerable.Range(1, count).Select(x => new JumpListItem(x, string.Format(title.Substring(0, 1) + ") Item #{0}", x))))
            {
                Items.Add(item);
            }
        }

        private void OnSelectedItemChanged(JumpListItem value)
        {
        }


    }

    public class LongJumpListViewModel : JumpListViewModel
    {
        protected override void InitItems()
        {
            AddItems("appointments", 4);
            AddItems("banking", 5);
            AddItems("credit cards", 3);
            AddItems("internet", 7);
            AddItems("notes", 3);
            AddItems("office", 5);
            AddItems("pins", 4);
            AddItems("private", 20);
            AddItems("today", 2);
        }
    }
}
