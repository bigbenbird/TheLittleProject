﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.ViewModels;
using OdcTest.Models;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Threading;
using Odyssey.Behaviors;
using System.Collections.ObjectModel;


namespace OdcTest.ViewModels
{
    public class DataViewModel : ViewModelBase
    {
        public DataViewModel()
            : base()
        {
            Items = new ObservableCollection<DataItem>();
            foreach(var item in Enumerable.Range(1, 150).Select(x => new DataItem(Items, x, string.Format("Item #{0}", x))))
            {
                Items.Add(item);
            }
            MenuCommand = new DelegateCommand(OnMenu);
        }


        public DelegateCommand MenuCommand { get; private set; }


        private int selectedIndex = 0;

        public int SelectedIndex
        {
            get { return selectedIndex; }
            set
            {
                if (selectedIndex != value)
                {
                    selectedIndex = value;
                    OnPropertyChanged("SelectedIndex");
                }
            }
        }


        private DataItem selectedItem;

        public DataItem SelectedItem
        {
            get { return selectedItem; }
            set
            {
                if (selectedItem != value)
                {
                    if (selectedItem != null) selectedItem.IsSelected = false;
                    selectedItem = value;
                    if (selectedItem != null) selectedItem.IsSelected = true;
                    OnPropertyChanged("SelectedItem");
                    OnSelectionChanged(value);
                }
            }
        }

        private void OnSelectionChanged(DataItem value)
        {

        }

        public IList<DataItem> Items { get; private set; }

        private void OnMenu(object p)
        {
            MessageBox.Show("Main Menu");
        }

    }
}
