﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using OdcTest.ViewModels;

namespace OdcTest
{
    public partial class MainPage : PhoneApplicationPage
    {
        private MainViewModel viewModel;

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            Unloaded += new RoutedEventHandler(MainPage_Unloaded);
        }

        void MainPage_Unloaded(object sender, RoutedEventArgs e)
        {
         //   forwardSB.Begin();
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            viewModel = DataContext as MainViewModel;
            if (viewModel != null) viewModel.SelectedItem = null;

            base.OnNavigatedTo(e);
        //    backwardSB.Begin();
        }



        protected override void OnNavigatingFrom(System.Windows.Navigation.NavigatingCancelEventArgs e)
        {
            base.OnNavigatingFrom(e);
     //       forwardSB.Begin();
        }

    }
}