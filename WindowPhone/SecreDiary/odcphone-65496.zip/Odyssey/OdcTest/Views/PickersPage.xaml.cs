﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Expression.Interactivity.Core;

namespace OdcTest.Views
{
    public partial class PickersPage : PhoneApplicationPage
    {
        public PickersPage()
        {
            InitializeComponent();
        }

        //class MyVSM:VisualStateManager
        //{
        //    protected override bool GoToStateCore(Control control, FrameworkElement templateRoot, string stateName, VisualStateGroup group, VisualState state, bool useTransitions)
        //    {
        //        ActionCommand cmd = new ActionCommand(doodle);
        //        return base.GoToStateCore(control, templateRoot, stateName, group, state, useTransitions);
        //    }

        //    void doodle()
        //    {
        //    }
        //}

        //class MyVT : VisualTransition
        //{
        //}

    }
}