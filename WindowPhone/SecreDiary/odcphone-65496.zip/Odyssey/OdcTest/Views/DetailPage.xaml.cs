﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Odyssey.Behaviors;
using System.Windows.Interactivity;

namespace OdcTest.Views
{
    public partial class DetailPage : PhoneApplicationPage
    {
        public DetailPage()
        {
            InitializeComponent();
        }

        private bool isPrepared;

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            if (!isPrepared)
            {
                string effectKey = NavigationContext.QueryString.ContainsKey("effect") ? NavigationContext.QueryString["effect"] as string : "continuumFx";
                if (!string.IsNullOrEmpty(effectKey))
                {
                    PageEffectBehavior effect = Resources[effectKey] as PageEffectBehavior;
                    if (effect != null)
                    {
                        Interaction.GetBehaviors(this).Add(effect);
                    }
                }
                isPrepared = true;
            }
            base.OnNavigatedTo(e);
        }

        private void OnOKClick(object sender, EventArgs e)
        {
            if (OkClick != null) OkClick(this, e);
        }

        private void OnCancelClick(object sender, EventArgs e)
        {
            if (CancelClick != null) CancelClick(this, e);
        }

        public event EventHandler OkClick;
        public event EventHandler CancelClick;

    }
}