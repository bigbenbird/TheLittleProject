﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.ViewModels;

namespace OdcTest.Models
{
    public class MainItem : ModelBase
    {
        public MainItem(string name, string url, string details = null, bool wait = false)
            : base()
        {
            this.details = details;
            this.name = name;
            this.url = url;
            this.wait = wait;
        }

        private string name;
        private string url;
        private string details;
        private bool wait;

        public string Details
        {
            get { return details; }
            set
            {
                if (details != value)
                {
                    details = value;
                    OnPropertyChanged("Details");
                }
            }
        }

        public bool Wait { get { return wait; } }


        public string Url
        {
            get { return url; }
            set
            {
                if (url != value)
                {
                    url = value;
                    OnPropertyChanged("Url");
                }
            }
        }

        public string Name
        {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    OnPropertyChanged("Name");
                }
            }
        }


    }
}
