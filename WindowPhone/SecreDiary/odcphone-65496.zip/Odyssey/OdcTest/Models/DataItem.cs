﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.ViewModels;
using System.Collections.Generic;
using Microsoft.Expression.Interactivity.Core;

namespace OdcTest.Models
{
    public class DataItem : ModelBase
    {
        public DataItem(IList<DataItem> owner, int id,string name)
            : base()
        {
            this.owner = owner;
            this.Id = id;
            this.name = name;
            MenuCommand = new DelegateCommand(OnMenu);
            DeleteCommand = new DelegateCommand(OnDelete);
            RenameCommand = new DelegateCommand(OnRename);
            InsertCommand = new DelegateCommand(OnInsert);
            OpenContextMenu = new DelegateCommand(OnOpenContextMenu);
        }

        public DataItem(IList<DataItem> owner, int id, string name, string details)
            : this(owner, id, name)
        {
            this.details = details;
        }

        private IList<DataItem> owner;
        private string name;
        private string details;
        private bool isContextMenuOpen;
        private bool isSelected;

        public bool IsSelected
        {
            get { return isSelected; }
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    OnPropertyChanged("IsSelected");
                }
            }
        }
        

        public bool IsContextMenuOpen
        {
            get { return isContextMenuOpen; }
            set
            {
                if (isContextMenuOpen != value)
                {
                    isContextMenuOpen = value;
                    OnPropertyChanged("IsContextMenuOpen");
                }
            }
        }
        

        public int Id { get; private set; }

        public DelegateCommand MenuCommand { get; private set; }
        public DelegateCommand DeleteCommand { get; private set; }
        public DelegateCommand RenameCommand { get; private set; }
        public DelegateCommand InsertCommand { get; private set; }
        public DelegateCommand OpenContextMenu { get; private set; }

        public string Details
        {
            get { return details; }
            set
            {
                if (details != value)
                {
                    details = value;
                    OnPropertyChanged("Details");
                }
            }
        }
        

        public string Name
        {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    OnPropertyChanged("Name");
                }
            }
        }


        private void OnMenu(object p)
        {
            MessageBox.Show(string.Format("Item {0} selected.",name));
        }

        private void OnDelete(object p)
        {
            owner.Remove(this);
        }

        private void OnRename(object p)
        {
            this.Name = "*" + this.Name;
        }

        private void OnInsert(object p)
        {
            DataItem newItem = new DataItem(owner, 1000 + Id, "New Item " + Id.ToString());
            int index = owner.IndexOf(this);
            owner.Insert(index, newItem);
        }

        private void OnOpenContextMenu(object p)
        {
            IsContextMenuOpen = true;
        }
    }
}
