﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.ViewModels
{
    public class DelegateCommand : ICommand
    {
        private Action<object> action;
        private Func<object, bool> canExecute;


        public DelegateCommand(Action<object> executeAction)
            : base()
        {
            this.action = executeAction;
        }

        public DelegateCommand(Action executeAction)
            : base()
        {
            this.action = (o) => executeAction();
        }


        public DelegateCommand(Action<object> executeAction, Func<object, bool> canExecute)
            : this(executeAction)
        {
            this.canExecute = canExecute;
        }

        public Action<object> ExecuteAction
        {
            get { return action; }
            set { action = value; }
        }

        public bool CanExecute(object parameter)
        {
            if (canExecute != null) return canExecute(parameter);
            return true;
        }

        public void OnCanExecuteChanged()
        {
            var eh = CanExecuteChanged;
            if (eh != null) eh(this, EventArgs.Empty);
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            if (action != null) action(parameter);
        }
    }


}
