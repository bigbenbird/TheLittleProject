﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.Controls;

namespace Odyssey.ViewModels
{
    public class GroupItem : IGroupItem
    {
        public GroupItem(string groupName)
            : base()
        {
            this.GroupName = groupName;
        }

        public bool IsHeader { get { return true; } }
        public bool IsEnabled { get { return true; } }

        public int ChildCount { get; internal set; }

        public string GroupName { get; private set; }
    }
}
