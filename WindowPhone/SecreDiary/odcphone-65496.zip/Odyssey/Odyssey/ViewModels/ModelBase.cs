﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Serialization;

namespace Odyssey.ViewModels
{
    [DataContract]
    [Serializable]
    public abstract class ModelBase : INotifyPropertyChanged
    {

        protected virtual void OnPropertyChanged(string propertyName)
        {
            CheckPropertyName(propertyName);
            var eh = PropertyChanged;
            if (eh != null) eh(this, new PropertyChangedEventArgs(propertyName));
        }

        [Conditional("DEBUG")]
        private void CheckPropertyName(string name)
        {
            if (!this.GetType().GetProperties().Any(p => p.Name == name))
            {
                throw new ArgumentOutOfRangeException(name, "property not found on class " + this.GetType().Name+".");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
