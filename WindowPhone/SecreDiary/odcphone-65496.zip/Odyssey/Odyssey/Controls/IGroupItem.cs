﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Controls
{
    /// <summary>
    /// Prepares a Model or ViewModel to be recognized by OdcListBox to contain additional data about being just data or
    /// a data header which launches the quick jump list.
    /// </summary>
    public interface IGroupItem
    {
        /// <summary>
        /// Gets whether the object is a data header.
        /// </summary>
        bool IsHeader { get; }

        /// <summary>
        /// Gets the name of the group.
        /// </summary>
        string GroupName { get; }

        /// <summary>
        /// Gets whether the data header is enabled.
        /// </summary>
        bool IsEnabled { get; }
    }

}
