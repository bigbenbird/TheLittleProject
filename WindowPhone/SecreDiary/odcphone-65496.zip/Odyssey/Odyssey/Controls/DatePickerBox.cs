﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.ViewModels;
using System.Windows.Data;

namespace Odyssey.Controls
{
    public class DatePickerBox : PickerBox
    {

        public class SelectorModel : ModelBase
        {
            private object selectedDate;

            public object SelectedDate
            {
                get { return selectedDate; }
                set
                {
                    if (selectedDate != value)
                    {
                        selectedDate = value;
                        OnPropertyChanged("SelectedDate");
                    }
                }
            }

        }

        public DatePickerBox()
            : base()
        {
            DefaultStyleKey = typeof(DatePickerBox);
        }


        /// <summary>
        /// Gets or sets the FormatString that formats the SelectedItem value.
        /// </summary>
        public string FormatString
        {
            get { return (string)GetValue(FormatStringProperty); }
            set { SetValue(FormatStringProperty, value); }
        }

        public static readonly DependencyProperty FormatStringProperty =
            DependencyProperty.Register("FormatString", typeof(string), typeof(DatePickerBox), new PropertyMetadata("d"));



        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            GetAppBarButton(0).Click += new EventHandler(OnOkClick);
            GetAppBarButton(1).Click += new EventHandler(OnCancelClick);
        }

        void OnCancelClick(object sender, EventArgs e)
        {
            IsOpen = false;
        }

        private SelectorModel model;

        void OnOkClick(object sender, EventArgs e)
        {
            if (model != null)
            {
                SelectedItem = model.SelectedDate;
                model = null;
            }
            IsOpen = false;
        }


        protected override void BindOverlayContent(Overlay overlay)
        {
            model = new SelectorModel { SelectedDate = SelectedItem ?? DateTime.Now };
            overlay.SetBinding(Overlay.ContentProperty, new Binding() { Source = model });
        }


        /// <summary>
        /// Called when [selected item changed].
        /// </summary>
        /// <param name="oldValue">The old value.</param>
        /// <param name="newValue">The new value.</param>
        protected override void OnSelectedItemChanged(object oldValue, object newValue)
        {
            if (!(newValue is DateTime)) Content = null;
            else
            {
                DateTime dt = (DateTime)newValue;
                Content = FormatDateTime(dt);
            }
        }

        protected virtual object FormatDateTime(DateTime dt)
        {
            return dt.ToString(FormatString);
            //return dt.ToShortDateString();
        }

    }
}
