﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Controls
{
    /// <summary>
    /// Specifies how the Overlay control is being displayed.
    /// </summary>
    public enum OverlayMode
    {
        /// <summary>
        /// Overlay determines it's mode automatially.
        /// This mode prefers Inline mode and switches to Popup mode if Inline is not possible since the Page's first child is not a Grid control.
        /// </summary>
        Auto,

        /// <summary>
        /// Overlay is added as last child to the page. This requires the page to have the first and only element to be a Grid.
        /// This mode allows transparency of the overlay content and is significantly faster to render than Popup mode.
        /// </summary>
        InPage,

        /// <summary>
        /// Application.RootVisual is temporarily replaced by a Grid which contains both, PhoneApplicationFrame and Overlay.
        /// </summary>
        InFrame,

        /// <summary>
        /// The PhoneApplicationPage is being replaced by the Overlay. 
        /// This mode does not allow transparency but is fastest to render.
        /// </summary>
        Replace,

        /// <summary>
        /// The Overlay is embedded in a Popup control
        /// This mode allows transparency and can be used with any PhoneApplicationPage but also impacts rendering performance at most.
        /// If possible, try to replace it by either InPage mode by ensuring that the first child element of the page is a Grid control, or use Replace if no transparency is required.
        /// </summary>
        Popup

    }
}
