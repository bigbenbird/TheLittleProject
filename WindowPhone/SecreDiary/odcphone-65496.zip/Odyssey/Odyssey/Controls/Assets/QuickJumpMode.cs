﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Controls
{
    public enum QuickJumpMode
    {
        /// <summary>
        /// The quick jump list is an alphabetical list.
        /// </summary>
        Alphabetical,

        /// <summary>
        /// The quick jump list is a custom, dynamic list.
        /// </summary>
        List
    }
}
