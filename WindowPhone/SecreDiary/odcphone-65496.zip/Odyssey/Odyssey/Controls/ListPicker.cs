﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.ViewModels;
using System.Windows.Threading;
using Odyssey.Utils;
using System.Linq;
using Odyssey.Controls.Internals;
using System.Collections.Generic;
using Microsoft.Phone.Shell;
using System.Collections;

namespace Odyssey.Controls
{
    public class ListPicker : PickerBox
    {
        /// <summary>
        /// ViewModel that connects the Button part with the overlay content.
        /// </summary>
        public class ListPickerModel : ModelBase
        {
            internal ListPickerModel(ListPicker picker, object itemsSource, object selectedItem, Style itemContainerStyle)
            {
                this.picker = picker;
                this.Items = itemsSource;
                this.selectedItem = selectedItem;
                this.ItemContainerStyle = itemContainerStyle;
            }

            private ListPicker picker;
            private object selectedItem;
            private object title;

            public object Title
            {
                get { return title; }
                set
                {
                    if (title != value)
                    {
                        title = value;
                        OnPropertyChanged("Title");
                    }
                }
            }

            public Style ItemContainerStyle { get; private set; }
            public DataTemplate ItemTemplate { get; set; }

            public object Items { get; private set; }

            public object SelectedItem
            {
                get { return selectedItem; }
                set
                {
                    if (selectedItem != value)
                    {
                        selectedItem = value;
                        OnPropertyChanged("SelectedItem");
                        OnSelectionChanged();
                    }
                }
            }

            private void OnSelectionChanged()
            {
                picker.IsOpen = false;
            }
        }

        private ListPickerModel model;


        public ListPicker()
            : base()
        {
            DefaultStyleKey = typeof(ListPicker);
        }



        /// <summary>
        /// Gets or sets the item container style.
        /// </summary>
        public Style ItemContainerStyle
        {
            get { return (Style)GetValue(ItemContainerStyleProperty); }
            set { SetValue(ItemContainerStyleProperty, value); }
        }

        public static readonly DependencyProperty ItemContainerStyleProperty =
            DependencyProperty.Register("ItemContainerStyle", typeof(Style), typeof(ListPicker), new PropertyMetadata(null));


        /// <summary>
        /// Gets or sets the item template.
        /// </summary>
        public DataTemplate ItemTemplate
        {
            get { return (DataTemplate)GetValue(ItemTemplateProperty); }
            set { SetValue(ItemTemplateProperty, value); }
        }

        public static readonly DependencyProperty ItemTemplateProperty =
            DependencyProperty.Register("ItemTemplate", typeof(DataTemplate), typeof(ListPicker), new PropertyMetadata(null));


        /// <summary>
        /// Gets or sets the title of the overlay page.
        /// </summary>
        public object Title
        {
            get { return (object)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register("Title", typeof(object), typeof(ListPicker), new PropertyMetadata(null));



        /// <summary>
        /// Gets or sets the items source.
        /// </summary>
        public IList ItemsSource
        {
            get { return (IList)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }

        public static readonly DependencyProperty ItemsSourceProperty =
            DependencyProperty.Register("ItemsSource", typeof(IList), typeof(ListPicker), new PropertyMetadata(null));


        public int SelectedIndex
        {
            get { return ItemsSource != null && SelectedItem != null ? ItemsSource.IndexOf(SelectedItem) : -1; }
            set
            {
                if (ItemsSource != null && value >= 0)
                {
                    SelectedItem = ItemsSource[value];
                }
            }
        }


        protected override void OnClosing(Overlay overlay)
        {
            overlay.StopScrollPanels();
            AnimateItemsToClose(overlay);
            if (model != null)
            {
                SelectedItem = model.SelectedItem;
                model = null;
            }
            base.OnClosing(overlay);
        }

        protected void AnimateItemsToClose(Overlay overlay)
        {
            Queue<OdcListBoxItem> queue = new Queue<OdcListBoxItem>(overlay.GetVisualDescendants().OfType<OdcListBoxItem>());

            if (queue.Count > 0)
            {
                DispatcherTimer timer = new DispatcherTimer
                {
                    Interval = TimeSpan.FromMilliseconds(20)
                };
                timer.Tick += delegate
                {
                    if (queue.Count > 0)
                    {
                        var item = queue.Dequeue();
                        VisualStateManager.GoToState(item, VisualStates.UnloadedState, true);

                    }
                    else timer.Stop();
                };
                timer.Start();
            }
        }


        protected override void BindOverlayContent(Overlay overlay)
        {
            model = new ListPickerModel(this, ItemsSource, SelectedItem, ItemContainerStyle);
            model.Title = this.Title;
            model.ItemTemplate = ItemTemplate;
            overlay.Content = model;
        }
    }
}
