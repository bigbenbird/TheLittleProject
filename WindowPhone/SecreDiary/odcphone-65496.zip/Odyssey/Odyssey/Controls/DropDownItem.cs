﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace Odyssey.Controls
{
    public class DropDownItem : ListBoxItem
    {
        public DropDownItem()
            : base()
        {
            base.DefaultStyleKey = typeof(DropDownItem);
            VerticalContentAlignment = System.Windows.VerticalAlignment.Center;
        }

        internal DropDown DropDown { get; set; }
        private bool canceled;


        protected override void OnManipulationStarted(ManipulationStartedEventArgs e)
        {
            canceled = false;
            base.OnManipulationStarted(e);
        }

        protected override void OnManipulationDelta(ManipulationDeltaEventArgs e)
        {
            canceled = true;
            base.OnManipulationDelta(e);
        }

        protected override void OnManipulationCompleted(ManipulationCompletedEventArgs e)
        {
            if (!e.Handled && !canceled)
            {
                if (DropDown != null) DropDown.OnItemClick();
             //#   e.Handled = true;
            }
            base.OnManipulationCompleted(e);
        }

        //protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
        //{
        //    Debug.WriteLine("left");
        //    base.OnMouseLeftButtonUp(e);
        //}
    }
}
