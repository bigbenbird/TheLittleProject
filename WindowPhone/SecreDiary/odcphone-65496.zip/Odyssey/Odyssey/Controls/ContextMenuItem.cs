﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Linq;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;
using Odyssey.Utils;
using Odyssey.Controls.Primitives;

namespace Odyssey.Controls
{
    public class ContextMenuItem : Button
    {

        public ContextMenuItem()
            : base()
        {
            DefaultStyleKey = typeof(ContextMenuItem);
        }



        /// <summary>
        /// Set to true in order to invoke the command after the context menu has closed, or false to invoke the command immediately.
        /// The default value is false.
        /// </summary>
        public bool InvokeOnMenuClosed
        {
            get { return (bool)GetValue(InvokeOnMenuClosedProperty); }
            set { SetValue(InvokeOnMenuClosedProperty, value); }
        }

        public static readonly DependencyProperty InvokeOnMenuClosedProperty =
            DependencyProperty.Register("InvokeOnMenuClosed", typeof(bool), typeof(ContextMenuItem), new PropertyMetadata(false));



        public object CommandParameter
        {
            get { return (object)GetValue(CommandParameterProperty); }
            set { SetValue(CommandParameterProperty, value); }
        }

        public static readonly DependencyProperty CommandParameterProperty =
            DependencyProperty.Register("CommandParameter", typeof(object), typeof(ContextMenuItem), new PropertyMetadata(null));


        public ICommand Command
        {
            get { return (ICommand)GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }

        public static readonly DependencyProperty CommandProperty =
            DependencyProperty.Register("Command", typeof(ICommand), typeof(ContextMenuItem), new PropertyMetadata(null));


        protected override void OnClick()
        {
            base.OnClick();
            ContextMenuOverlay container = this.GetVisualAncestors().OfType<ContextMenuOverlay>().FirstOrDefault();
            if (container != null)
            {
                if (Command != null || Invoked != null)
                {
                    if (InvokeOnMenuClosed)
                    {
                        container.Closed += new EventHandler(HandleInvokeOnMenuClosed);
                    }
                    else
                    {
                        if (Command != null)
                        {
                            var param = CommandParameter ?? this.DataContext;
                            Dispatcher.BeginInvoke(() => Command.Execute(param));
                        } 
                    }
                }
                container.IsOpen = false;
            }
            else
            {
                if (Command != null)
                {
                    var param = CommandParameter ?? this.DataContext;
                    Dispatcher.BeginInvoke(() => Command.Execute(param));
                }
            }
        }

        public event EventHandler Invoked;

        void HandleInvokeOnMenuClosed(object sender, EventArgs e)
        {
            ContextMenuOverlay overlay = sender as ContextMenuOverlay;
            if (overlay == null) throw new ArgumentNullException("overlay");

            overlay.Closed -= HandleInvokeOnMenuClosed;
            if (Command != null)
            {
                var param = CommandParameter ?? this.DataContext;
                Dispatcher.BeginInvoke(() => Command.Execute(param));
            }
            if (Invoked != null) Invoked(this, EventArgs.Empty);
        }

    }
}
