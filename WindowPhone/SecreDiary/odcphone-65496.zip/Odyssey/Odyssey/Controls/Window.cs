﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Shell;

namespace Odyssey.Controls
{
    public class Window : Control
    {
        public Window()
            : base()
        {
        //    Unloaded += new RoutedEventHandler(Window_Unloaded);
        }

        void Window_Unloaded(object sender, RoutedEventArgs e)
        {
            if (overlay != null) overlay.IsOpen = false;
            overlay = null;
        }


        private Overlay overlay;


        /// <summary>
        /// Gets or sets the application bar to show while opened.
        /// </summary>
        public IApplicationBar ApplicationBar
        {
            get { return (IApplicationBar)GetValue(ApplicationBarProperty); }
            set { SetValue(ApplicationBarProperty, value); }
        }

        public static readonly DependencyProperty ApplicationBarProperty =
            DependencyProperty.Register("ApplicationBar", typeof(IApplicationBar), typeof(Window), new PropertyMetadata(null));



        /// <summary>
        /// Gets or sets the content in the window.
        /// </summary>
        public object Content
        {
            get { return (object)GetValue(ContentProperty); }
            set { SetValue(ContentProperty, value); }
        }

        public static readonly DependencyProperty ContentProperty =
            DependencyProperty.Register("Content", typeof(object), typeof(Window), new PropertyMetadata(null));

        /// <summary>
        /// Gets or sets the data template of the window.
        /// </summary>
        public DataTemplate ContentTemplate
        {
            get { return (DataTemplate)GetValue(ContentTemplateProperty); }
            set { SetValue(ContentTemplateProperty, value); }
        }

        public static readonly DependencyProperty ContentTemplateProperty =
            DependencyProperty.Register("ContentTemplate", typeof(DataTemplate), typeof(Window), new PropertyMetadata(null));



        public ControlTemplate OverlayTemplate
        {
            get { return (ControlTemplate)GetValue(OverlayTemplateProperty); }
            set { SetValue(OverlayTemplateProperty, value); }
        }

        // Using a DependencyProperty as the backing store for OverlayTemplate.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OverlayTemplateProperty =
            DependencyProperty.Register("OverlayTemplate", typeof(ControlTemplate), typeof(Window), new PropertyMetadata(null));




        public bool IsOpen
        {
            get { return (bool)GetValue(IsOpenProperty); }
            set { SetValue(IsOpenProperty, value); }
        }

        public static readonly DependencyProperty IsOpenProperty =
            DependencyProperty.Register("IsOpen", typeof(bool), typeof(Window), new PropertyMetadata(false, OnOpenedChanged));

        private static void OnOpenedChanged(DependencyObject o, DependencyPropertyChangedEventArgs args)
        {
            bool isOpened = (bool)args.NewValue;
            (o as Window).OnOpenedChanged(isOpened);
        }

        private void OnOpenedChanged(bool isOpened)
        {
            if (isOpened)
            {
                if (overlay == null)
                {
                    overlay = new Overlay(this);
                    overlay.Closing += (s, e) =>
                        {
                            IsOpen = false;
                        };

                }
                overlay.ContentTemplate = ContentTemplate;
                overlay.Content = Content ?? this.DataContext;
                overlay.DataContext = this.DataContext;
                overlay.ApplicationBar = ApplicationBar;

                ControlTemplate overlayTemplate = OverlayTemplate;
                if (overlayTemplate == null) overlay.ClearValue(Overlay.TemplateProperty); else overlay.Template = overlayTemplate;
                overlay.IsOpen = true;
            }
            else
            {
                if (overlay != null) overlay.IsOpen = false;
                overlay = null;
            }
        }
    }
}
