﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.ViewModels;

namespace Odyssey.Controls.Models
{
    /// <summary>
    /// Data item used by OdcListBox used for showing quick jump items.
    /// </summary>
    public class QuickJumpItem : ModelBase
    {
        private static Brush enabledBrush;
        private static Brush disabledBrush;
        private static Brush disabledForegroundBrush;
        private static Brush foregroundBrush;

        static QuickJumpItem()
        {
            enabledBrush = Application.Current.Resources["PhoneAccentBrush"] as Brush;
            disabledBrush = Application.Current.Resources["PhoneChromeBrush"] as Brush;
            disabledForegroundBrush = Application.Current.Resources["PhoneForegroundBrush"] as Brush;
            foregroundBrush = new SolidColorBrush(Color.FromArgb(255, 255, 255, 255));

        }

        public QuickJumpItem(string name)
            : base()
        {
            this.Name = name;
            background = disabledBrush;
            foreground = disabledForegroundBrush;
        }
        private bool isEnabled;
        private double opacity = 0.3;
        private Brush background;
        private Brush foreground;

        public Brush Foreground
        {
            get { return foreground; }
            set
            {
                if (foreground != value)
                {
                    foreground = value;
                    OnPropertyChanged("Foreground");
                }
            }
        }


        public Brush Background
        {
            get { return background; }
            private set
            {
                if (background != value)
                {
                    background = value;
                    OnPropertyChanged("Background");
                }
            }
        }


        public double Opacity
        {
            get { return opacity; }
            private set
            {
                if (opacity != value)
                {
                    opacity = value;
                    OnPropertyChanged("Opacity");
                }
            }
        }

        public bool IsEnabled
        {
            get { return isEnabled; }
            set
            {
                if (isEnabled != value)
                {
                    isEnabled = value;
                    OnPropertyChanged("IsEnabled");
                    Opacity = value ? 1 : 0.3;
                    Background = value ? enabledBrush : disabledBrush;
                    Foreground = value ? foregroundBrush : disabledForegroundBrush;
                }
            }
        }


        public string Name { get; private set; }

        /// <summary>
        /// Gets or sets the index of the item in the list.
        /// </summary>
        public int JumpIndex { get; set; }
    }
}
