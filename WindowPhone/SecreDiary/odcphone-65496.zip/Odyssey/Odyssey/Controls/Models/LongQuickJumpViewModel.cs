﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Linq;
using System.Collections.Generic;

namespace Odyssey.Controls.Models
{
    public class LongQuickJumpViewModel : QuickJumpViewModel
    {
        protected override void CreateItemsList()
        {
        }

        protected override int GetIndexFromName(string name)
        {
            if (string.IsNullOrEmpty(name)) return 0;
            int index = Items.Where((item, i) => string.Equals(name, item.Name, StringComparison.InvariantCultureIgnoreCase)).Select((item, i) => i).FirstOrDefault();
            return index;
        }


        public override void UpdateFromItemsSource(System.Collections.IList itemsSource)
        {
            Items = new List<QuickJumpItem>();

            if (itemsSource != null)
            {
                for (int i = 0; i < itemsSource.Count; i++)
                {
                    IGroupItem item = itemsSource[i] as IGroupItem;
                    if (item != null && item.IsHeader)
                    {
                        Items.Add(new QuickJumpItem(item.GroupName) { IsEnabled = true, JumpIndex = i });
                    }
                }
            }
        }
       
    }
}
