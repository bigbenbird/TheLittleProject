﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;
using System.Collections;

namespace Odyssey.Controls
{
    public class ThrottledSourceConverter : IValueConverter
    {
        public ThrottledSourceConverter()
            : base()
        {
            Interval = TimeSpan.FromMilliseconds(1);
            To = 10;
        }

        public TimeSpan Interval { get; set; }
        public int From { get; set; }
        public int To { get; set; }

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            IList source = value as IList;
            if (source == null) return null;

            IntervalDataSource ds = new IntervalDataSource
            {
                Interval = this.Interval,
                StartCount = this.From,
                Threshold = this.To,
                ItemsSource = source,
            };
            return ds.Items;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value;
        }
    }
}
