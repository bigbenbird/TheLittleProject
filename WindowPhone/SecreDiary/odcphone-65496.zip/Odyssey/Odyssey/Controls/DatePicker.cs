﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.ViewModels;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Odyssey.Controls.Models;
using System.Windows.Data;

namespace Odyssey.Controls
{
    [TemplatePart(Name = partDayPicker, Type = typeof(ItemPicker))]
    [TemplatePart(Name = partMonthPicker, Type = typeof(ItemPicker))]
    [TemplatePart(Name = partYearPicker, Type = typeof(ItemPicker))]
    public class DatePicker : Control
    {
        const string partDayPicker = "PART_DayPicker";
        const string partMonthPicker = "PART_MonthPicker";
        const string partYearPicker = "PART_YearPicker";

        public DatePicker()
            : base()
        {
            base.DefaultStyleKey = typeof(DatePicker);

            model = new DatePickerModel();
            Context = model;
            //SetBinding(DateProperty, new Binding("Date") { Source = model, Mode= BindingMode.TwoWay });
            //Date = model.Date;
            model.DateChanged += (s, e) => Date = model.Date;
        }

        private DatePickerModel model;


        /// <summary>
        /// Gets or sets the selected date.
        /// </summary>
        public DateTime Date
        {
            get { return (DateTime)GetValue(DateProperty); }
            set { SetValue(DateProperty, value); }
        }




        public object Context
        {
            get { return (object)GetValue(ContextProperty); }
            private set { SetValue(ContextProperty, value); }
        }

        public static readonly DependencyProperty ContextProperty =
            DependencyProperty.Register("Context", typeof(object), typeof(DatePicker), new PropertyMetadata(null));

        
        

        /// <summary>
        /// Gets the data model that contains details about the selected day, month and year.
        /// </summary>
        public DatePickerModel Model { get { return model; } }

        public static readonly DependencyProperty DateProperty =
            DependencyProperty.Register("Date", typeof(DateTime), typeof(DatePicker), new PropertyMetadata(DateTime.Now, OnDateChanged));

        private static void OnDateChanged(DependencyObject o, DependencyPropertyChangedEventArgs args)
        {
            (o as DatePicker).OnDateChanged((DateTime)args.OldValue, (DateTime)args.NewValue);
        }

        protected virtual void OnDateChanged(DateTime oldValue, DateTime newValue)
        {
            model.Date = newValue;
            var eh = DateChanged;
            if (eh != null) eh(this, EventArgs.Empty);
        }



        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            if (VisualTreeHelper.GetChildrenCount(this) > 0)
            {
      //          (VisualTreeHelper.GetChild(this, 0) as FrameworkElement).DataContext = Model;
            }

            var part1 = GetTemplateChild(partDayPicker) as FrameworkElement;
            Grid.SetColumn(part1, DatePickerModel.DayOrderIndex);
            var part2 = GetTemplateChild(partMonthPicker) as FrameworkElement;
            Grid.SetColumn(part2, DatePickerModel.MonthOrderIndex);
            var part3 = GetTemplateChild(partYearPicker) as FrameworkElement;
            Grid.SetColumn(part3, DatePickerModel.YearOrderIndex);
        }

        public event EventHandler DateChanged;


    }
}
