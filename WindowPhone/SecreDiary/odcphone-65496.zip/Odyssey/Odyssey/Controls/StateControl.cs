﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Controls
{
    /// <summary>
    /// Control for binding visual state with the Viewmodel.
    /// This control as no default template as it is intended to be used inside a ControlTemplate to bind one or more visual states with the viewmodel.
    /// </summary>
    public class StateControl : Control
    {

        public StateControl()
            : base()
        {
            //Loaded += (s, e) => isLoaded = true;
            //Unloaded += (s, e) => isLoaded = false;
        }


        /// <summary>
        /// Gets or sets the state for the first group.
        /// </summary>
        public string State1
        {
            get { return (string)GetValue(State1Property); }
            set { SetValue(State1Property, value); }
        }

        public static readonly DependencyProperty State1Property =
            DependencyProperty.Register("State1", typeof(string), typeof(StateControl), new PropertyMetadata("Rest1", OnStateChanged));


        /// <summary>
        /// Gets or sets the state for the second group.
        /// </summary>
        public string State2
        {
            get { return (string)GetValue(State2Property); }
            set { SetValue(State2Property, value); }
        }

        public static readonly DependencyProperty State2Property =
            DependencyProperty.Register("State2", typeof(string), typeof(StateControl), new PropertyMetadata("Rest2", OnStateChanged));


        /// <summary>
        /// Gets or sets the state for the third group.
        /// </summary>
        public string State3
        {
            get { return (string)GetValue(State3Property); }
            set { SetValue(State3Property, value); }
        }

        public static readonly DependencyProperty State3Property =
            DependencyProperty.Register("State3", typeof(string), typeof(StateControl), new PropertyMetadata("Rest3", OnStateChanged));


        private static void OnStateChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
        {
            StateControl c = (StateControl)o;
            string state = e.NewValue as string;

           // VisualStateManager.GoToState(c, state, c.isLoaded);
            VisualStateManager.GoToState(c, state, true);
        }


    }
}
