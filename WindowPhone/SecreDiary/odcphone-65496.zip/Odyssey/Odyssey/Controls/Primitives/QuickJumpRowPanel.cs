﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Controls.Primitives
{
    internal class QuickJumpRowPanel : Panel
    {
        protected override Size ArrangeOverride(Size finalSize)
        {
            double left = 0d;
            foreach (UIElement child in Children)
            {
                Size size = child.DesiredSize;
                child.Arrange(new Rect(left, 0d, ItemWidth, ItemHeight));
                left += ItemWidth;
            }
            return base.ArrangeOverride(finalSize);
        }

        public double ItemWidth;
        public double ItemHeight;

    }
}
