﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Controls.Primitives
{
    public class ClippingPanel : Panel
    {

        protected override Size MeasureOverride(Size availableSize)
        {
            foreach (var child in Children) child.Measure(availableSize);
            return base.MeasureOverride(availableSize);
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            var size = base.ArrangeOverride(finalSize);
            Rect rect = new Rect(0, 0, size.Width, size.Height);
            foreach (var child in Children) child.Arrange(rect);
            ClipRegion(size);
            return size;
        }

        private void ClipRegion(Size finalSize)
        {
            RectangleGeometry g = this.Clip as RectangleGeometry;
            if (g == null)
            {
                g = new RectangleGeometry();
                this.Clip = g;
            }
            g.Rect = new Rect(0.0, 0.0, finalSize.Width, finalSize.Height);
        }

    }
}
