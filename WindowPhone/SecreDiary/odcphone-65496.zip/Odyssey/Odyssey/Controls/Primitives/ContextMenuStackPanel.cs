﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Controls.Primitives
{
    /// <summary>
    /// Used in ContextMenuOverlay template to layout the anchor element (child 0) and the context menu items panel (child 1).
    /// </summary>
    public class ContextMenuStackPanel : Panel
    {

        /// <summary>
        /// Gets or sets if the second element is at the top.
        /// </summary>
        public bool IsAbove
        {
            get { return (bool)GetValue(IsAboveProperty); }
            set { SetValue(IsAboveProperty, value); }
        }

        public static readonly DependencyProperty IsAboveProperty =
            DependencyProperty.Register("IsAbove", typeof(bool), typeof(ContextMenuStackPanel), new PropertyMetadata(false, OnPropertyChanged));

        private static void OnPropertyChanged(DependencyObject o, DependencyPropertyChangedEventArgs args)
        {
            (o as UIElement).InvalidateArrange();
        }


        /// <summary>
        /// Gets or sets the left position of the first element.
        /// </summary>
        public double HorizontalOffset
        {
            get { return (double)GetValue(HorizontalOffsetProperty); }
            set { SetValue(HorizontalOffsetProperty, value); }
        }

        public static readonly DependencyProperty HorizontalOffsetProperty =
            DependencyProperty.Register("HorizontalOffset", typeof(double), typeof(ContextMenuStackPanel), new PropertyMetadata(0.0, OnPropertyChanged));


        /// <summary>
        /// Gets or sets the top position of the first element.
        /// </summary>
        public double VerticalOffset
        {
            get { return (double)GetValue(VerticalOffsetProperty); }
            set { SetValue(VerticalOffsetProperty, value); }
        }

        public static readonly DependencyProperty VerticalOffsetProperty =
            DependencyProperty.Register("VerticalOffset", typeof(double), typeof(ContextMenuStackPanel), new PropertyMetadata(0.0, OnPropertyChanged));



        protected override Size MeasureOverride(Size availableSize)
        {
            if (double.IsInfinity(availableSize.Width) || double.IsInfinity(availableSize.Height))
            {
                return base.MeasureOverride(availableSize);
            }
            int n = Math.Min(Children.Count, 2);
            Size measureSize = new Size(double.PositiveInfinity, double.PositiveInfinity);
            for (int i = 0; i < n; i++)
            {
                UIElement child = Children[i];
                child.Measure(measureSize);
                measureSize = availableSize;
            }
            return availableSize;
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            int n = Children.Count;
            if (n == 1)
            {
                UIElement child = Children[0];
                double h = child.DesiredSize.Height;
                child.Arrange(new Rect(HorizontalOffset, VerticalOffset, child.DesiredSize.Width, h));
            }
            else if (n > 1)
            {
                UIElement child0 = Children[0];
                UIElement child1 = Children[1];
                double h0 = child0.DesiredSize.Height;
                double h1 = child1.DesiredSize.Height;

                double top0 = VerticalOffset;
                double top1 = IsAbove ? top0 - h1 : top0 + h0;

                if (top1 < 0d) top1 = 0d;
                else if ((top1 + h1) > finalSize.Height) top1 = finalSize.Height - h1;

                child0.Arrange(new Rect(HorizontalOffset, top0, child0.DesiredSize.Width, h0));
                child1.Arrange(new Rect(0d, top1, finalSize.Width, h1));
            }
            return finalSize;

        }
    }
}
