﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace Odyssey.Controls
{
    /// <summary>
    /// If implemented by a panel, the panel exposes the children in an ordered way.
    /// </summary>
    /// <example>
    /// Used by VirtualizingItemsPanel.
    /// </example>
    public interface IOrderedChildren
    {
        /// <summary>
        /// Gets all children in an ordered ways.
        /// </summary>
        /// <returns>Ordered children.</returns>
        IEnumerable<DependencyObject> GetOrderedChildren();
    }
}
