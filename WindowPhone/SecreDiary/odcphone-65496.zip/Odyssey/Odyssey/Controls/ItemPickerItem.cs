﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Controls
{
    public class ItemPickerItem : ContentControl
    {
        public ItemPickerItem()
            : base()
        {
            this.DefaultStyleKey = typeof(ItemPickerItem);
        }



        internal ItemPicker Picker;

        public bool IsExpanded
        {
            get { return (bool)GetValue(IsExpandedProperty); }
            set { SetValue(IsExpandedProperty, value); }
        }

        public static readonly DependencyProperty IsExpandedProperty =
            DependencyProperty.Register("IsExpanded", typeof(bool), typeof(ItemPickerItem), new PropertyMetadata(false, OnExpansionChanged));

        private static void OnExpansionChanged(DependencyObject o, DependencyPropertyChangedEventArgs args)
        {
            bool newValue = (bool)args.NewValue;
            (o as ItemPickerItem).OnExpansionChanged(!newValue, newValue);
        }

        protected virtual void OnExpansionChanged(bool oldValue, bool newValue)
        {
            VisualStateManager.GoToState(this, GetCommonState(), true);
        }
        

        /// <summary>
        /// Gets whether the item is selected.
        /// </summary>
        public bool IsSelected
        {
            get { return (bool)GetValue(IsSelectedProperty); }
            internal set { SetValue(IsSelectedProperty, value); }
        }

        public static readonly DependencyProperty IsSelectedProperty =
            DependencyProperty.Register("IsSelected", typeof(bool), typeof(ItemPickerItem), new PropertyMetadata(false, OnSelectionChanged));


        private static void OnSelectionChanged(DependencyObject o, DependencyPropertyChangedEventArgs args)
        {
            bool newValue = (bool)args.NewValue;
            ItemPickerItem item = o as ItemPickerItem;

            VisualStateManager.GoToState(item, item.GetCommonState(), true);
            item.OnSelectionChanged(!newValue, newValue);
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            VisualStateManager.GoToState(this, GetCommonState(), false);
        }

        private string GetCommonState()
        {
            if (IsSelected) return "Selected";
            return IsExpanded ? "Expanded" : "Collapsed";
        }

        protected virtual void OnSelectionChanged(bool oldValue, bool newValue)
        {
            if (newValue) IsExpanded = true;
        }

        protected override void OnManipulationStarted(ManipulationStartedEventArgs e)
        {
            base.OnManipulationStarted(e);
        }

        protected override void OnManipulationCompleted(ManipulationCompletedEventArgs e)
        {
            if (!e.Handled)
            {
                if (Math.Abs(e.TotalManipulation.Translation.Y) < 5)
                {
                    e.Handled = true;
                    if (Picker != null)
                    {
                        bool isExpanded = Picker.IsExpanded;
                        if (IsSelected)
                        {
                            Picker.IsExpanded ^= true;
                        }
                        else
                        {
                            Picker.IsExpanded = true;
                        }
                        if (isExpanded)
                        {
                            if (Picker.SelectedItem != this.Content)
                            {
                                Picker.SelectedItem = this.Content;
                            }
                            else
                            {
                                Picker.BalanceSelectedItem(true);
                            }
                        }
                    }
                }
            }
            base.OnManipulationCompleted(e);
        }
    }
}
