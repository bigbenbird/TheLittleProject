﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows;
using System.Collections;

namespace Odyssey.Controls
{
    public interface IInfiniteLoopHost
    {
        bool IsScrolling { get; }

        bool IsExpanded { get; }

        double ItemHeight { get; }

        IList ItemsSource { get; }

        object SelectedItem { get; }

        FrameworkElement CreateItem(int index, out bool isNew);

        void ReleaseItemContainer(int index);

        void PrepareItem(ItemPickerItem item);

        void ClearCache();
    }
}
