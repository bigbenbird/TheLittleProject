﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Controls
{
    [TemplateVisualState(Name = "Opened", GroupName = "CommonStates")]
    [TemplateVisualState(Name = "Closed", GroupName = "CommonStates")]
    public class AnimatedContentControl : ContentControl
    {
        public AnimatedContentControl()
            : base()
        {
            DefaultStyleKey = typeof(AnimatedContentControl);
        }


        public bool IsOpen
        {
            get { return (bool)GetValue(IsOpenProperty); }
            set { SetValue(IsOpenProperty, value); }
        }

        public static readonly DependencyProperty IsOpenProperty =
            DependencyProperty.Register("IsOpen", typeof(bool), typeof(AnimatedContentControl), new PropertyMetadata(false, OnOpenChanged));

        private static void OnOpenChanged(DependencyObject o, DependencyPropertyChangedEventArgs args)
        {
            bool newValue = (bool)args.NewValue;

            (o as AnimatedContentControl).OnOpenedChanged(!newValue, newValue);
        }

        protected virtual void OnOpenedChanged(bool oldValue, bool newValue)
        {
            VisualStateManager.GoToState(this, newValue ? "Opened" : "Closed", true);
            //if (newValue) OpenPopup(); else ClosePopup();
        }

        public void Close()
        {
            VisualStateManager.GoToState(this, "Closed", true);
        }
        
    }
}
