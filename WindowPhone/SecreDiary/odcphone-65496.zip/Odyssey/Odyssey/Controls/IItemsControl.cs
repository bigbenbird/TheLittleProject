﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections;

namespace Odyssey.Controls
{
    /// <summary>
    /// Specifies the requirements for an items control that associates with OdcVirtualizingPanel.
    /// </summary>
    public interface IItemsControl
    {
        /// <summary>
        /// Gets or creates an ItemContainer for an item.
        /// </summary>
        /// <param name="index">Index of the item for which to get or create the container.</param>
        /// <param name="isNew">True if the container is newly created, otherwise false.</param>
        /// <returns>ItemContainer control.</returns>
        FrameworkElement GetItemContainer(int index, out bool isNew);

        /// <summary>
        /// Releases an ItemContainer for reuse.
        /// </summary>
        /// <param name="index">Index of the item for which to release the ItemContainer.</param>
        void ReleaseItemContainer(int index);

        /// <summary>
        /// Optionally to initialize an ItemContainer after it was attached by the ItemsPanel.
        /// </summary>
        /// <param name="index">Index of item.</param>
        /// <param name="item">ItemContainer which was attached.</param>
        void ItemContainerAttached(int index, FrameworkElement item);

        /// <summary>
        /// Gets the height of the item. A ItemsPanel may use this value to arrange ItemContainers.
        /// </summary>
        double ItemHeight { get; }

        /// <summary>
        /// Gets the width  of the item. A ItemsPanel may use this value to arrange ItemContainers.
        /// </summary>
        double ItemWidth { get; }

        /// <summary>
        /// Gets the source of items.
        /// </summary>
        IList ItemsSource { get; }

        /// <summary>
        /// Gets the actual height of the ItemsControl
        /// </summary>
        double ActualHeight { get; }

        /// <summary>
        /// Gets or sets whether the ItemsPanel should layout all visible item in intervals.
        /// </summary>
        bool IsIntervalEnabled { get; }
    }
}
