﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Interactivity
{
    /// <summary>
    /// Event trigger which opens a message box to be accepted to raise the event.
    /// </summary>
    /// <remarks>
    /// Caption and Text can be localized by resolving the applied value with the static ResolveText event.
    /// </remarks>
    public class MessageEventTrigger :DelayedEventTrigger
    {

        /// <summary>
        /// Gets or sets the caption of the message box.
        /// </summary>
        public string Caption
        {
            get { return (string)GetValue(CaptionProperty); }
            set { SetValue(CaptionProperty, value); }
        }


        /// <summary>
        /// Gets or sets the text in the message box.
        /// </summary>
        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(MessageEventTrigger), new PropertyMetadata(string.Empty));
         

        public static readonly DependencyProperty CaptionProperty =
            DependencyProperty.Register("Caption", typeof(string), typeof(MessageEventTrigger), new PropertyMetadata("confirm"));


        protected override void OnEvent(EventArgs eventArgs)
        {
            string text = OnResolveText(Text);
            string caption = OnResolveText(Caption);
            if (MessageBox.Show(text, caption, MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                base.OnEvent(eventArgs);
            }
        }

        private string OnResolveText(string text)
        {
            var eh = ResolveText;
            if (eh != null)
            {
                var args = new MessageTriggerEventArgs(text);
                eh(this, args);
                text = args.Text;
            }
            return text;
        }


        /// <summary>
        /// Gets or sets the event that occurs when to resolve either Caption or Text.
        /// This handler is usefull for localizing Caption or Text since binding is not yet possible on Triggers.
        /// </summary>
        public static event EventHandler<MessageTriggerEventArgs> ResolveText;
    }
}
