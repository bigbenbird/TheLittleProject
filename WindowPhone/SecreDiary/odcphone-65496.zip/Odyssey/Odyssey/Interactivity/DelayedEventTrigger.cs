﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Interactivity;
using System.Windows.Threading;

namespace Odyssey.Interactivity
{
    /// <summary>
    /// Event trigger that invokes it's actions after a specified delay.
    /// </summary>
    public class DelayedEventTrigger:System.Windows.Interactivity.EventTrigger
    {
        /// <summary>
        /// Gets or sets the number of milliseconds to elapse after the event before the actions are invoked.
        /// </summary>
        public int Milliseconds
        {
            get { return (int)GetValue(MillisecondsProperty); }
            set { SetValue(MillisecondsProperty, value); }
        }

        public static readonly DependencyProperty MillisecondsProperty =
            DependencyProperty.Register("Milliseconds", typeof(int), typeof(DelayedEventTrigger), new PropertyMetadata(100));


        protected override void OnEvent(EventArgs eventArgs)
        {
            //base.OnEvent(eventArgs);
            DispatcherTimer timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(Milliseconds) };
            timer.Tick += new EventHandler(timer_Tick);
            timer.Start();
        }

        void timer_Tick(object sender, EventArgs e)
        {
            DispatcherTimer timer = sender as DispatcherTimer;
            timer.Stop();

            this.InvokeActions(null);
        }
    }
}
