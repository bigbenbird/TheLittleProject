﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Interactivity
{
    public class MessageTriggerEventArgs : EventArgs
    {
        /// <summary>
        /// Gets or sets the text to be resolved.
        /// </summary>
        public string Text { get; set; }

        public MessageTriggerEventArgs(string text)
            : base()
        {
            this.Text = text;
        }
    }
}
