﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.Effects;

namespace Odyssey.Behaviors
{
    /// <summary>
    /// Page transition effect that performs a feathered turnstile effect.
    /// In order to enable this effect, all UIElements in the page template which apply to the effect must be decorated with FeatherEffect.IsElement.
    /// </summary>
    public class FeatherEffectAction : PageEffectAction<FeatherEffect>
    {
        public FeatherEffectAction()
            : base()
        {
            this.Angle = 117.0;
        }

        public double Angle
        {
            get { return Effect.Angle; }
            set { Effect.Angle = value; }
        }




        /// <summary>
        /// Gets or sets the amplitude of the feather effect. 
        /// </summary>
        public double Amplitude
        {
            get {return Effect.Amplitude;}
            set { Effect.Amplitude = value; }
        }
    }
}
