﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Behaviors
{
    /// <summary>
    /// Provides a swing effect on a page during navigating from and to the page.
    /// </summary>
    public class SwingEffectBehavior : PageEffectBehavior<Odyssey.Effects.SwingEffect>
    {
        public double Angle { get { return Effect.Angle; } set { Effect.Angle = value; } }

    }
}
