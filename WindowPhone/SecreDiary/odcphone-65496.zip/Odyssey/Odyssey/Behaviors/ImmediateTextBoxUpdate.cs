﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Behaviors
{
    public class ImmediateTextBoxUpdate
    {

        public static bool GetIsEnabled(DependencyObject obj)
        {
            return (bool)obj.GetValue(IsEnabledProperty);
        }

        public static void SetIsEnabled(DependencyObject obj, bool value)
        {
            obj.SetValue(IsEnabledProperty, value);
        }

        public static readonly DependencyProperty IsEnabledProperty =
            DependencyProperty.RegisterAttached("IsEnabled", typeof(bool), typeof(ImmediateTextBoxUpdate), new PropertyMetadata(false, OnEnabledChanged));

        private static void OnEnabledChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
        {
            TextBox tb = o as TextBox;
            if (tb == null) throw new ArgumentOutOfRangeException("ImmediateTextBoxUpdate can only be attached on TextBox contols.");
            bool value = (bool)e.NewValue;

            if (value)
            {
                tb.TextChanged += new TextChangedEventHandler(OnTextChanged);
            }
            else
            {
                tb.TextChanged-= OnTextChanged;
            }
        }

        static void OnTextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox tb = sender as TextBox;
            SetText(tb, tb.Text);
        }
       

        public static string GetText(DependencyObject obj)
        {
            return (string)obj.GetValue(TextProperty);
        }

        public static void SetText(DependencyObject obj, string value)
        {
            obj.SetValue(TextProperty, value);
        }

        public static readonly DependencyProperty TextProperty =
            DependencyProperty.RegisterAttached("Text", typeof(string), typeof(ImmediateTextBoxUpdate), new PropertyMetadata(null));

        
    }
}
