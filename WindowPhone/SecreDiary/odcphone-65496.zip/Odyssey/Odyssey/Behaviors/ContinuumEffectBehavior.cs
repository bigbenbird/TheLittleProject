﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.Effects;

namespace Odyssey.Behaviors
{
    public class ContinuumEffectBehavior : PageEffectBehavior<ContinuumEffect>
    {
        /// <summary>
        /// Gets or sets whether the effect is for a master or detail page.
        /// </summary>
        public ContinuumMode Mode
        {
            get { return Effect.Mode; }
            set { Effect.Mode = value; }
        }
    }
}
