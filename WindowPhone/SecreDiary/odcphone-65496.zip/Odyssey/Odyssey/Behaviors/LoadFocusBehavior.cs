﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Interactivity;

namespace Odyssey.Behaviors
{
    /// <summary>
    /// Sets the focus on a textbox after load.
    /// </summary>
    public class LoadFocusBehavior : Behavior<TextBox>
    {
        protected override void OnAttached()
        {
            AssociatedObject.LayoutUpdated += new EventHandler(OnLayoutUpdated);
            base.OnAttached();
        }


        public bool SelectAll { get; set; }

        void OnLayoutUpdated(object sender, EventArgs e)
        {
            AssociatedObject.LayoutUpdated -= OnLayoutUpdated;
            if (FocusManager.GetFocusedElement() != AssociatedObject)
            {
                AssociatedObject.Focus();
                if (SelectAll) AssociatedObject.SelectAll();
            }
        }

        protected override void OnDetaching()
        {
            AssociatedObject.LayoutUpdated -= OnLayoutUpdated;
            base.OnDetaching();
        }

    }
}
