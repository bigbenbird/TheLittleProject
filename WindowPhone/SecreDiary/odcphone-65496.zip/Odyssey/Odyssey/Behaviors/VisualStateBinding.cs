﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Odyssey.Behaviors
{
    /// <summary>
    /// Attaches VisualState property to controls in order to bind the visual state with a view model.
    /// </summary>
    public class VisualStateBinding
    {


        public static string GetVisualState(DependencyObject obj)
        {
            return (string)obj.GetValue(VisualStateProperty);
        }

        public static void SetVisualState(DependencyObject obj, string value)
        {
            obj.SetValue(VisualStateProperty, value);
        }

        public static readonly DependencyProperty VisualStateProperty =
            DependencyProperty.RegisterAttached("VisualState", typeof(string), typeof(VisualStateBinding), new PropertyMetadata("", OnStateChanged));

        private static void OnStateChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
        {
            Control c = o as Control;
            if (c == null) throw new ArgumentOutOfRangeException("VisualState", "Property works only on Controls.");

            string stateName=e.NewValue as string;
            VisualStateManager.GoToState(c, stateName, true);
        }

        
    }
}
