﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.Effects;

namespace Odyssey.Behaviors
{
    /// <summary>
    /// Provides the continuum effect on a page which is used for transitioning from a master to a detail page by animating the selected item on the page.
    /// This action requires the view to set the attached ContinuumEffect.IsItem property set to true on one item in order to animate it. Optionally, another element
    /// can set the attached ContinuumEffect.Slide property to true to apply a slide up or down effect in the transition.
    /// </summary>
    public class ContimuumEffectAction : PageEffectAction<ContinuumEffect>
    {
        /// <summary>
        /// Gets or sets whether the effect is for a master or detail page.
        /// </summary>
        public ContinuumMode Mode
        {
            get { return Effect.Mode; }
            set { Effect.Mode = value; }
        }

        public bool IsItemEnabled
        {
            get { return Effect.IsItemEnabled; }
            set { Effect.IsItemEnabled = false; }                
        }

        /// <summary>
        /// Gets or sets the name of the anchestor element which contains the element which is marked with IsElement=true. If not set, the element is searched within the whole page.
        /// </summary>
        public string Scope
        {
            get { return Effect.Scope; }
            set { Effect.Scope = value; }
        }

        public double MasterReturnScale
        {
            get { return Effect.MasterReturnScale; }
            set { Effect.MasterReturnScale = value; }
        }
    }
}
