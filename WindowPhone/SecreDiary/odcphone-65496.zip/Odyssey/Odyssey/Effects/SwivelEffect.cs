﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.Utils;

namespace Odyssey.Effects
{
    public class SwivelEffect : PageEffect
    {

        public double Angle { get; set; }

        protected override void Initialize()
        {
            Duration = TimeSpan.FromMilliseconds(250.0);
            Angle = -60.0;
        }


        protected override void Activate(Microsoft.Phone.Controls.PhoneApplicationPage page, Storyboard storyboard)
        {

            PlaneProjection projection = page.GetPlaneProjection(true);
            projection.CenterOfRotationX = 0.0;

            Timeline timeline = new DoubleAnimation
            {
                To = Angle,
                EasingFunction = new ExponentialEase { EasingMode = EasingMode.EaseIn, Exponent=5d }
            };
            AddTimeline(timeline, projection, "RotationX");

            timeline = new DoubleAnimation
            {
                To = 0.0,
                EasingFunction = new ExponentialEase { EasingMode = EasingMode.EaseIn, Exponent = 25d }
            };
            AddTimeline(timeline, page, "Opacity");
        }

        protected override void Deactivate(Microsoft.Phone.Controls.PhoneApplicationPage page, Storyboard storyboard, bool isActivated)
        {
            PlaneProjection projection = page.GetPlaneProjection(true);
            projection.CenterOfRotationX = 0.0;
            if (!isActivated)
            {
                projection.RotationX = Angle;
                page.Opacity = 0.0;
            }

            Timeline timeline = new DoubleAnimation
            {
                To = 0.0,
                EasingFunction = new ExponentialEase { EasingMode = EasingMode.EaseOut, Exponent=5d }
            };
            AddTimeline(timeline, projection, "RotationX");
            timeline = new DoubleAnimation
            {
                To = 1.0,
                EasingFunction = new ExponentialEase { EasingMode = EasingMode.EaseOut, Exponent = 25d }
            };
            AddTimeline(timeline, page, "Opacity");
        }
    }
}
