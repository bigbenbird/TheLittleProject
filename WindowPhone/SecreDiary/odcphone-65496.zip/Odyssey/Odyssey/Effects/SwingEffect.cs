﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.Utils;

namespace Odyssey.Effects
{
    public class SwingEffect : PageEffect
    {

        public double Angle { get; set; }

        protected override void Initialize()
        {
            base.Initialize();
            Angle = 90.0;
        }

        protected override void Activate(Microsoft.Phone.Controls.PhoneApplicationPage page, Storyboard storyboard)
        {
            PlaneProjection projection = page.GetPlaneProjection(true);
            projection.CenterOfRotationX = 0.0;

            {
                Timeline timeline = new DoubleAnimation
                {
                    Duration = this.Duration,
                    To = Angle,
                    EasingFunction = new ExponentialEase { EasingMode = EasingMode.EaseIn, Exponent = 5d }
                };
                Storyboard.SetTarget(timeline, projection);
                Storyboard.SetTargetProperty(timeline, new PropertyPath("RotationY"));
                storyboard.Children.Add(timeline);
            }
            {
                Timeline timeline = new DoubleAnimation
                {
                    Duration = this.Duration,
                    To = 0.0,
                    EasingFunction = new ExponentialEase { Exponent = 20d, EasingMode = EasingMode.EaseIn }
                };
                Storyboard.SetTarget(timeline, page);
                Storyboard.SetTargetProperty(timeline, new PropertyPath("Opacity"));
                storyboard.Children.Add(timeline);
            }
        }

        protected override void Deactivate(Microsoft.Phone.Controls.PhoneApplicationPage page, Storyboard storyboard, bool isActive)
        {
            PlaneProjection projection = page.GetPlaneProjection(true);
            //PlaneProjection projection = new PlaneProjection();
            page.Projection = projection;
            projection.CenterOfRotationX = 0.0;
            if (!isActive)
            {
                projection.RotationY = Angle;
                page.Opacity = 0.0;
            }
            {
                Timeline timeline = new DoubleAnimation
                {
                    Duration = this.Duration,
                    To = 0.0,
                    EasingFunction = new ExponentialEase { EasingMode = EasingMode.EaseOut, Exponent = 5d }
                };
                Storyboard.SetTarget(timeline, projection);
                Storyboard.SetTargetProperty(timeline, new PropertyPath("RotationY"));
                storyboard.Children.Add(timeline);
            }
            {
                Timeline timeline = new DoubleAnimation
                {
                    Duration = this.Duration,
                    To = 1.0,
                    EasingFunction = new ExponentialEase { Exponent = 20d, EasingMode = EasingMode.EaseOut }
                };
                Storyboard.SetTarget(timeline, page);
                Storyboard.SetTargetProperty(timeline, new PropertyPath("Opacity"));
                storyboard.Children.Add(timeline);
            }
        }
    }
}
