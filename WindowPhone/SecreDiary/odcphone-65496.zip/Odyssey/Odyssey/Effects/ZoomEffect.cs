﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.Utils;

namespace Odyssey.Effects
{
    public class ZoomEffect : PageEffect
    {
        public double ZOffset { get; set; }


        protected override void Initialize()
        {
            Duration = TimeSpan.FromMilliseconds(250.0);
            ZOffset = 800.0;
        }


        protected override void Activate(Microsoft.Phone.Controls.PhoneApplicationPage page, Storyboard storyboard)
        {
            PlaneProjection projection = page.GetPlaneProjection(true);

            Timeline timeline = new DoubleAnimation
            {
                To = ZOffset,
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseIn }
            };
            AddTimeline(timeline, projection, "GlobalOffsetZ");

            timeline = new DoubleAnimation
            {
                To = 0.0,
                EasingFunction = new ExponentialEase { EasingMode = EasingMode.EaseIn, Exponent = 5 }
            };
            AddTimeline(timeline, page, "Opacity");
        }

        protected override void Deactivate(Microsoft.Phone.Controls.PhoneApplicationPage page, Storyboard storyboard, bool isActivated)
        {
            PlaneProjection projection = page.GetPlaneProjection(true);
            projection.CenterOfRotationX = 0.0;
            double? from = null;
            if (!isActivated)
            {
                projection.GlobalOffsetZ = ZOffset;
                page.Opacity = 0.0;
                from = 0.0;
            }



            Timeline timeline = new DoubleAnimation
            {
                To = 0.0,
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
            };
            AddTimeline(timeline, projection, "GlobalOffsetZ");
            timeline = new DoubleAnimation
            {
                From = from,
                To = 1.0,
                EasingFunction = new ExponentialEase { EasingMode = EasingMode.EaseOut, Exponent = 5 }
            };
            AddTimeline(timeline, page, "Opacity");
        }
    }
}
