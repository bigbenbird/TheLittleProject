﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Odyssey.Controls;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Odyssey.Utils
{
    public static class ListUtil
    {
    //    //public static int GetInsertIndex<T>(this IList<T> list, string name, int min, int max) where T : IWriteableQuickJumpItem
    //    //{
    //    //    max = Math.Min(max, list.Count);
    //    //    for (int i = min; i < max; i++)
    //    //    {
    //    //        if (string.Compare(list[i].Title, name, StringComparison.OrdinalIgnoreCase) >= 0) return i;
    //    //    }
    //    //    return max;
    //    //}

    //    //public static int GetInsertIndexOfGroup<T>(this IList<T> list, string name, int min, int max) where T : IWriteableQuickJumpItem
    //    //{
    //    //    max = Math.Min(max, list.Count);
    //    //    for (int i = min; i < max; i++)
    //    //    {
    //    //        T item = list[i];
    //    //        if (item.IsHeader) return i;
    //    //        if (string.Compare(item.Title, name, StringComparison.OrdinalIgnoreCase) >= 0) return i;
    //    //    }
    //    //    return max;
    //    //}

        public static ObservableCollection<T> ToObservableCollection<T>(this IEnumerable<T> source)
        {
            ObservableCollection<T> result=new ObservableCollection<T>();
            if (source!=null)
            {
            foreach(var item in source) result.Add(item);
            }
            return result;
        }
    }
}
