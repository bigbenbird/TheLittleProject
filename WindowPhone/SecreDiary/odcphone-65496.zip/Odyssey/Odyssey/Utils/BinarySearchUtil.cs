﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections;
using System.Collections.Generic;

namespace Odyssey.Utils
{
    public static class BinarySearchUtil
    {
        public static int BinarySearch<T>(IList array, int index, int length, T value, IComparer<T> comparer)
        {
            int low = index;
            int hi = (index + length) - 1;
            while (low <= hi)
            {
                int num8;
                int median = GetMedian(low, hi);
                num8 = comparer.Compare((T)array[median], value);
                if (num8 == 0)
                {
                    return median;
                }
                if (num8 < 0)
                {
                    low = median + 1;
                }
                else
                {
                    hi = median - 1;
                }
            }
            return ~low;
        }

        private static int GetMedian(int a, int b)
        {
            return (a + b) / 2;
        }
    }

}
