﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Shell;
using Microsoft.Phone.Controls;
using System.Resources;

namespace Odyssey.Utils
{
    public static class AppUtils
    {
        /// <summary>
        /// Gets a ApplicationBarMenuItem from a page.
        /// </summary>
        /// <param name="page">Page for which to get a ApplicationBarMenuItem by index.</param>
        /// <param name="index">Index of the ApplicationBarMenuItem.</param>
        /// <returns>ApplicationBarMenuItem or null.</returns>
        public static ApplicationBarMenuItem AppMenuItem(this PhoneApplicationPage page, int index)
        {
            if (page == null) throw new ArgumentNullException("page");
            ApplicationBar bar = page.ApplicationBar as ApplicationBar;
            if (bar == null) throw new ArgumentNullException("ApplicationBar");
            var items = bar.MenuItems;
            if (items == null) throw new ArgumentNullException("MenuItems");
            if (index < 0 || index >= items.Count) throw new ArgumentOutOfRangeException("index");
            return items[index] as ApplicationBarMenuItem;
        }

        /// <summary>
        /// Gets a ApplicationBarIconButton from a page
        /// </summary>
        /// <param name="page">Page for which to get a ApplicationBarIconButton by index.</param>
        /// <param name="index">Index of the ApplicationBarIconButton.</param>
        /// <returns>ApplicationBarIconButton or null.</returns>
        public static ApplicationBarIconButton AppButton(this PhoneApplicationPage page, int index)
        {
            if (page == null) throw new ArgumentNullException("page");
            ApplicationBar bar = page.ApplicationBar as ApplicationBar;
            if (bar == null) throw new ArgumentNullException("ApplicationBar");
            var buttons = bar.Buttons;
            if (buttons == null) throw new ArgumentNullException("Buttons");
            if (index < 0 || index >= buttons.Count) throw new ArgumentOutOfRangeException("index");
            return buttons[index] as ApplicationBarIconButton;
        }

        public static void LocalizeAppButtons(this PhoneApplicationPage page, params string[] localizedTitles)
        {
            if (page == null) throw new ArgumentNullException("page");
            if (localizedTitles == null) throw new ArgumentNullException("localizedTitles");
            ApplicationBar bar = page.ApplicationBar as ApplicationBar;
            LocalizeButtons(bar, localizedTitles);
        }

        public static void LocalizeAppBar(this IApplicationBar bar, ResourceManager resources)
        {
            if (bar.Buttons != null)
            {
                foreach (ApplicationBarIconButton btn in bar.Buttons)
                {
                    string txt = resources.GetString(btn.Text);
                    if (!string.IsNullOrEmpty(txt))
                    {
                        btn.Text = txt;
                    }
                }
            }

            if (bar.MenuItems != null)
            {
                foreach (ApplicationBarMenuItem item in bar.MenuItems)
                {
                    string txt = resources.GetString(item.Text);
                    if (!string.IsNullOrEmpty(txt)) item.Text = txt;
                }
            }
        }

        public static void LocalizeButtons(this ApplicationBar bar, params string[] localizedTitles)
        {
            if (bar == null) throw new ArgumentNullException("ApplicationBar");
            var buttons = bar.Buttons;
            if (buttons == null) throw new ArgumentNullException("Buttons");
            for (int i = 0; i < localizedTitles.Length; i++)
            {
                (buttons[i] as ApplicationBarIconButton).Text = localizedTitles[i];
            }
        }

        public static void LocalizeAppMenuItems(this PhoneApplicationPage page, params string[] localizedTitles)
        {
            if (page == null) throw new ArgumentNullException("page");
            if (localizedTitles == null) throw new ArgumentNullException("localizedTitles");
            ApplicationBar bar = page.ApplicationBar as ApplicationBar;
            if (bar == null) throw new ArgumentNullException("ApplicationBar");
            var items = bar.MenuItems;
            if (items == null) throw new ArgumentNullException("MenuItems");
            for (int i = 0; i < localizedTitles.Length; i++)
            {
                (items[i] as ApplicationBarMenuItem).Text = localizedTitles[i];
            }
        }
    }
}
